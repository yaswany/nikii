package com.ts.obo.management.device.persistence.nosql;

import com.ts.obo.management.device.model.MomsMessageMapping;
import com.ts.obo.management.device.persistence.MomsMessageMappingRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * The interface Moms message mapping repository.
 */
@Qualifier("MomsMessageMappingRepository")
@Repository
public interface MomsMessageMappingNosqlRepository extends CrudRepository<MomsMessageMapping, Integer>, MomsMessageMappingRepository {

}
