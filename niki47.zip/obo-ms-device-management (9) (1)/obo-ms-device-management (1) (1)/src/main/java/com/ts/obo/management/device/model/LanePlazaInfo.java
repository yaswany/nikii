package com.ts.obo.management.device.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LanePlazaInfo {

    @JsonProperty(value = "laneId")
    int laneId;
    @JsonProperty(value = "plazaId")
    int plazaId;

}

