package com.ts.obo.management.device.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.google.common.cache.CacheBuilder;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

/**
 * Cache config
 */
@Configuration
@EnableCaching
public class CacheConfig extends CachingConfigurerSupport {
    @Value("${cache.expiry-time}")
    Integer expiryTime;
    @Value("${cache.maximum-size}")
    Integer maxSize;

    @Bean
    @Override
    public CacheManager cacheManager() {
        ConcurrentMapCacheManager cacheManager = new ConcurrentMapCacheManager() {

            @Override
            protected Cache createConcurrentMapCache(final String name) {
                return new ConcurrentMapCache(name, CacheBuilder.newBuilder().expireAfterWrite(expiryTime, TimeUnit.MINUTES)
                        .maximumSize(maxSize).build().asMap(), false);
            }
        };

        cacheManager.setCacheNames(Arrays.asList("OBOCache"));
        return cacheManager;
    }

}
