package com.ts.obo.management.device.service;

import com.ts.obo.management.device.client.AppClient;
import com.ts.obo.management.device.exception.ErrorType;
import com.ts.obo.management.device.model.*;
import com.ts.obo.management.device.exception.OBOException;
import com.ts.obo.management.device.model.dto.MomsMessageWorkOrders;
import com.ts.obo.management.device.model.dto.MomsCMMSWorkOrder;
import com.ts.obo.management.device.model.dto.PlazaLaneListDTO;
import com.ts.obo.management.device.persistence.MomsMessageMappingRepository;
import com.ts.obo.management.device.persistence.MomsMessageRepository;
import com.ts.obo.management.device.persistence.MomsWorkOrderRepository;

import com.ts.obo.management.device.util.JsonMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static org.aspectj.runtime.internal.Conversions.intValue;

/**
 * The type Moms message service.
 */
@Slf4j
@Service
public class MomsMessageServiceImpl {

    /**
     * The Moms message repository.
     */
    @Autowired
    MomsMessageRepository momsMessageRepository;

    /**
     * The Moms work order repository.
     */
    @Autowired
    MomsWorkOrderRepository momsWorkOrderRepository;

    /**
     * The Moms message mapping repository.
     */
    @Autowired
    MomsMessageMappingRepository momsMessageMappingRepository;

    @Value("${moms.status.open}")
    String statusOpen;

    @Value("${moms.status.close}")
    String statusClose;

    /**
     * The App client.
     */
    @Autowired
    AppClient appClient;


    /**
     * Insert/Update records into t_moms_message_tx
     * Insert records if alarmId is not exists for open status.
     * update record if alarmId exist for close status
     *
     * @param momsKafkaMessage the moms kafka message
     * @return the boolean
     */
    public boolean  insertAndUpdateMomsMessageTx(String momsKafkaMessage) {
        MomsInsertMessage momsInsertMessage;
        try{

      momsInsertMessage = JsonMapper.toObject(momsKafkaMessage, MomsInsertMessage.class);
      log.info("momsInsertMessage>>Description:: {}::agencyId:: {}::status:: {}::msgCode::{}",
              momsInsertMessage.getDescription(),momsInsertMessage.getAgencyId(),momsInsertMessage.getStatus()
      ,momsInsertMessage.getMsgCode());

       String findMomsByDescription ;
       MomsMessageMapping momsMessageMapping;
       MomsMessage momsMessage ;

       if(momsInsertMessage.getMsgCode().equalsIgnoreCase("TAG FILE")){
           findMomsByDescription = momsInsertMessage.getDescription()+"-".concat(String.valueOf(momsInsertMessage.getAgencyId()));
       }else{
           findMomsByDescription = momsInsertMessage.getDescription();
       }

       momsMessageMapping = momsMessageMappingRepository.findByMsgCode(findMomsByDescription);
       if(momsMessageMapping==null){
           log.info("Message description is not available in t_moms_message_mapping");
           return false;
       }

       if(momsInsertMessage.getStatus().equalsIgnoreCase(statusOpen)){

           momsMessage = momsMessageRepository.findByMsgCodeForOpen(momsInsertMessage.getMsgCode());
           if(momsMessage==null){
                   momsMessage = new MomsMessage();

                   if(momsInsertMessage.getPlazaId()!=0) {
                       momsMessage.setPlazaId(momsInsertMessage.getPlazaId());
                       momsMessage.setLaneId(momsInsertMessage.getLaneId());
                   }else{
                       momsMessage.setPlazaId(setLanePlazaId().getPlazaId());
                       momsMessage.setLaneId(setLanePlazaId().getLaneId());
                   }
                   momsMessage.setTxDate(new Date());
                   momsMessage.setMessageCode(momsInsertMessage.getMsgCode());
                   momsMessage.setUpdateTs(new Date());
                   momsMessage.setSentFlag(0);
                   momsMessage.setSentTs(new Date());
                   momsMessage.setEquipId(momsMessageMapping.getEquipmentId());
                   momsMessage.setAlarmId(momsMessageMapping.getRepairNumber());
                   momsMessage.setDescription(momsMessageMapping.getMsgCode());
                   momsMessage.setOpenSentFlag(0);
                   momsMessage.setCloseSentFlag(1);
                   momsMessage.setOpenSentTs(new Date());
                   momsMessageRepository.save(momsMessage);
               log.info("Record inserted successfully");
               }else{
               log.info("open alarm Exist, so ignore");
           }

       }else if(momsInsertMessage.getStatus().equalsIgnoreCase(statusClose)){
           momsMessage = momsMessageRepository.findByMsgCodeForClose(momsInsertMessage.getMsgCode());
           if(momsMessage!=null) {
               if (momsMessage.getAlarmId() != -1) {
                   momsMessage.setCloseSentFlag(0);
                   momsMessage.setCloseSentTs(new Date());
                   momsMessageRepository.save(momsMessage);
                   log.info("Record updated successfully for alarm: {}",momsMessage.getAlarmId());
               }
           }else{
               log.info("NO open alarm exist for status close");
           }
       }

       return true;
    }catch(DataAccessException exception){
        throw new OBOException(exception.getMessage(), ErrorType.ValidationError,exception.getCause());
    }catch(Exception exception){
       throw new OBOException(exception.getMessage(), ErrorType.InternalError);
    }
   }

    /**
     * Get min plazaId and laneId from plazaAdmin MS
     * if not available or exceptions then set default values
     * @return
     */
    private MomsMessage setLanePlazaId() {
        var momsMessage = new MomsMessage();
        try{
            ResponseEntity<String> jsonString =  appClient.getLanePlazaId();

            if(null != jsonString && jsonString.getBody()!=null) {
                LanePlazaInfo response = JsonMapper.toObject(jsonString.getBody(), LanePlazaInfo.class);
                momsMessage.setPlazaId(Objects.requireNonNull(response).getPlazaId());
                momsMessage.setLaneId(response.getLaneId());
                log.info("LaneId::{}::PlazaId::{}",momsMessage.getLaneId(),momsMessage.getPlazaId());
            }else{
                momsMessage.setPlazaId(900);
                momsMessage.setLaneId(2000);
                log.info("Reset plaza/lane for moms");
            }
        }catch(Exception exception){
            momsMessage.setPlazaId(900);
            momsMessage.setLaneId(2000);
            log.error("setLanePlazaId method::{}",exception);
        }
        return momsMessage;
    }

    /**
     * Get all work orders list.
     *
     * @param pageSize the page size
     * @return the list
     */
    public List<MomsCMMSWorkOrder> getAllWorkOrders(int pageSize){

        List<MomsMessageWorkOrders> momsMessageWorkOrders;
        List<MomsCMMSWorkOrder> momsCMMSWorkOrder =new ArrayList<>();

        List<PlazaLaneListDTO> lanePlazaList =  appClient.getLaneAndPlazaList();
        log.debug("lanePlazaList.size()::::"+lanePlazaList.size());

        momsMessageWorkOrders= momsMessageRepository.getAllWorkOrders(pageSize,getPlazaId(lanePlazaList),getLaneId(lanePlazaList));

        log.debug("getAllWorkOrders.size()::::"+momsCMMSWorkOrder.size());
        momsMessageWorkOrders.stream().forEach(moms -> {
            lanePlazaList.stream().filter(lane -> lane.getPlazaId()==moms.getPlazaId() &&
                    lane.getLaneId()==moms.getLaneId()).forEach(plazaLane -> {

                momsCMMSWorkOrder.add(new MomsCMMSWorkOrder(moms.getPlazaId(),moms.getLaneId(),moms.getEquipId(),
                        moms.getAlarmId(),moms.getDescription(),moms.getWoStatus(),moms.getWoNumber(),
                        moms.getOpenSentFlag(),moms.getCloseSentFlag(),plazaLane.getExternPlazaId(),
                        plazaLane.getExternLaneId(),plazaLane.getName()));
            });
        });

        log.info("momsCMMSWorkOrder.size()::::"+momsCMMSWorkOrder.size());

        momsCMMSWorkOrder.stream().forEach(x -> {
           log.debug("ExternalPlazaId::{}::PlazaId::{}::ExternalLaneId()::{}::LaneId::{} ",
                    x.getExternalPlazaId(),x.getPlazaId(),x.getExternalLaneId(),x.getLaneId());
         });

        return  momsCMMSWorkOrder;
   }

    /**
     * Get plaza id list.
     *
     * @param lanePlazaId the lane plaza id
     * @return the list
     */
    public List<Integer> getPlazaId(List<PlazaLaneListDTO>  lanePlazaId){
        return lanePlazaId.stream().map(a -> intValue(a.getPlazaId())).collect(Collectors.toList());
    }

    /**
     * Get lane id list.
     *
     * @param lanePlazaId the lane plaza id
     * @return the list
     */
    public List<Integer> getLaneId(List<PlazaLaneListDTO>  lanePlazaId){
        return lanePlazaId.stream().map(a -> intValue(a.getLaneId())).collect(Collectors.toList());
    }

    /**
     * Update open wo info
     * in t_mom_message_tx and t_moms_work_order tables.
     *
     * @param woNumber the wo number
     * @param equipId  the equip id
     * @param alarmId  the alarm id
     * @param plazaId  the plaza id
     * @param laneId   the lane id
     */
    public void updateOpenWO(int woNumber, int equipId, int alarmId, int plazaId, int laneId){
       updateMomsMessageTxToOpenWO(woNumber,equipId,alarmId,plazaId,laneId);
       updateMomsWorkOrderToOpenWO(woNumber,equipId,alarmId,plazaId,laneId);
   }

    /**
     * Update moms message tx open wo.
     *
     * @param woNumber the wo number
     * @param equipId  the equip id
     * @param alarmId  the alarm id
     * @param plazaId  the plaza id
     * @param laneId   the lane id
     */
    public void updateMomsMessageTxToOpenWO(int woNumber,int equipId, int alarmId, int plazaId, int laneId){

        MomsMessage updateMoms= momsMessageRepository.findMomsMessageForOpenWO(equipId,alarmId,plazaId,laneId);

        if(updateMoms!=null){
            updateMoms.setWoNumber(woNumber);
            updateMoms.setOpenSentFlag(1);
            updateMoms.setOpenSentTs(new Date());
            updateMoms.setWoStartTime(new Date());
            updateMoms.setWoStatus(statusOpen);
            momsMessageRepository.save(updateMoms);
        }
   }

    /**
     * Update moms work order open wo.
     *
     * @param woNumber the wo number
     * @param equipId  the equip id
     * @param alarmId  the alarm id
     * @param plazaId  the plaza id
     * @param laneId   the lane id
     */
    public void updateMomsWorkOrderToOpenWO(int woNumber,int equipId, int alarmId, int plazaId, int laneId){

        MomsWorkOrder updateWorkOrder = momsWorkOrderRepository.findWorkOrderByIds(equipId,alarmId,plazaId,laneId);

        if(updateWorkOrder!=null){
            updateWorkOrder.setWoNumber(woNumber);
            updateWorkOrder.setWoStatus(statusOpen);
            updateWorkOrder.setWoStartTime(new Date());
            updateWorkOrder.setWoEndTime(null);
            updateWorkOrder.setUpdateTs(new Date());
            momsWorkOrderRepository.save(updateWorkOrder);
        }
   }

    /**
     * Update close wo info
     * in t_mom_message_tx and t_moms_work_order tables.
     *
     * @param equipId the equip id
     * @param alarmId the alarm id
     * @param plazaId the plaza id
     * @param laneId  the lane id
     */
    public void updateCloseWO(int equipId, int alarmId, int plazaId, int laneId){
       updateMomsMessageTxToCloseWO(equipId,alarmId,plazaId,laneId);
       updateMomsWorkOrderToCloseWO(equipId,alarmId,plazaId,laneId);
   }

    /**
     * Update moms message tx close wo.
     *
     * @param equipId the equip id
     * @param alarmId the alarm id
     * @param plazaId the plaza id
     * @param laneId  the lane id
     */
    public void updateMomsMessageTxToCloseWO(int equipId, int alarmId, int plazaId, int laneId){

        MomsMessage updateMoms= momsMessageRepository.findMomsMessageForCloseWO(equipId,alarmId,plazaId,laneId);

        if(updateMoms!=null){
            updateMoms.setCloseSentFlag(1);
            updateMoms.setCloseSentTs(new Date());
            updateMoms.setWoEndTime(new Date());
            updateMoms.setWoStatus(statusClose);
            momsMessageRepository.save(updateMoms);
        }
   }

    /**
     * Update moms work order close wo.
     *
     * @param equipId the equip id
     * @param alarmId the alarm id
     * @param plazaId the plaza id
     * @param laneId  the lane id
     */
    public void updateMomsWorkOrderToCloseWO(int equipId, int alarmId, int plazaId, int laneId){
       MomsWorkOrder updateWorkOrder = momsWorkOrderRepository.findWorkOrderByIds(equipId,alarmId,plazaId,laneId);

        if(updateWorkOrder!=null){
            updateWorkOrder.setWoNumber(-1);
            updateWorkOrder.setWoStartTime(null);
            updateWorkOrder.setWoEndTime(null);
            updateWorkOrder.setUpdateTs(new Date());
            updateWorkOrder.setWoStatus(null);
            momsWorkOrderRepository.save(updateWorkOrder);
        }
   }
}