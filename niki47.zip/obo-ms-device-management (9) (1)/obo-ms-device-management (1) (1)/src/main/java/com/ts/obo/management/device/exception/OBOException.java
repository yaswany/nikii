package com.ts.obo.management.device.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class OBOException extends RuntimeException {

	private static final long serialVersionUID = -9079454849611061074L;
	ErrorType errorType;
	String message;

	public OBOException(String message,ErrorType errorType) {
		super(message);
		this.message = message;
		this.errorType =errorType;
	}

	public OBOException(String message,ErrorType errorType,Throwable cause) {
		super(message,cause);
		this.message = message;
		this.errorType =errorType;
	}

	@Override
	public String getMessage(){
		return new StringBuilder().append(errorType.name()).append(" : ").append(message).toString();
	}

}