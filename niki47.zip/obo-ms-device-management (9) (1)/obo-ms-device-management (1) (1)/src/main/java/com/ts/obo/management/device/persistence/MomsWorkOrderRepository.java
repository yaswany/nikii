package com.ts.obo.management.device.persistence;

import com.ts.obo.management.device.model.MomsWorkOrder;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface MomsWorkOrderRepository extends ITransportationRepository<MomsWorkOrder, Integer> {

   @Query
   MomsWorkOrder findWorkOrderByIds(int equipId, int repairNumber, int plazaId, int laneId);

}