package com.ts.obo.management.device.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class JsonMapper {

    private JsonMapper(){
        // no code
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(JsonMapper.class);

    private static final ObjectMapper mapper = new ObjectMapper();

    public static <T> T toObject(String jsonString, Class<T> object) {

        try {
            return mapper.readValue(jsonString, object);
        } catch (IOException e) {
            LOGGER.error("Error while converting json to object :" + e.getMessage(), e);
        }
        return null;
    }

   }
