package com.ts.obo.management.device.momsmessage;

import com.ts.obo.management.device.service.MomsWorkOrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Date;

@Slf4j
@Service
public class MOMSWorkOrderScheduler {

	@Autowired
	private MomsWorkOrderService momsService;
	
	@Scheduled(cron="${interval.for.moms.WO}", zone="UTC")
	public void createWO() {
		log.info("Running now :: "+new Date(System.currentTimeMillis()));
		try {
			log.info("Creating MOMS Workorders");
			momsService.processWOCreation(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}