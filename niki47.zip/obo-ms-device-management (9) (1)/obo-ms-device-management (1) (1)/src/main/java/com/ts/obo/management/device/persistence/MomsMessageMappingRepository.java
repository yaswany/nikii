package com.ts.obo.management.device.persistence;

import com.ts.obo.management.device.model.MomsMessageMapping;
import org.springframework.data.repository.NoRepositoryBean;

/**
 * The interface Moms message mapping repository.
 */
@NoRepositoryBean
public interface MomsMessageMappingRepository extends ITransportationRepository<MomsMessageMapping, Integer> {

    MomsMessageMapping findByMsgCode(String msgCode);
}
