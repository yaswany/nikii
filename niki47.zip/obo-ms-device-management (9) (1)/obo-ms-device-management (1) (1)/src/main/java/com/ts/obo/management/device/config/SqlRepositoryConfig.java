package com.ts.obo.management.device.config;


import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;


@Profile("sql")
@Configuration
public class SqlRepositoryConfig {

}
