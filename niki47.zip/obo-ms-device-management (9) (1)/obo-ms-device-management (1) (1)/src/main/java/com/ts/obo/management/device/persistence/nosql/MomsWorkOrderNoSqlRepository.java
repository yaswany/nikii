package com.ts.obo.management.device.persistence.nosql;

import com.ts.obo.management.device.model.MomsWorkOrder;
import com.ts.obo.management.device.persistence.MomsWorkOrderRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Qualifier("MomsWorkOrderRepository")
@Repository
public interface MomsWorkOrderNoSqlRepository extends CrudRepository<MomsWorkOrder, Integer>, MomsWorkOrderRepository {

}