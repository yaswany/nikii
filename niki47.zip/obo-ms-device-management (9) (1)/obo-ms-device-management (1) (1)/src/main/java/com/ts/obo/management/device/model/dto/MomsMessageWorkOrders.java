package com.ts.obo.management.device.model.dto;

public interface  MomsMessageWorkOrders {

      int getPlazaId(); // internalPlazaId
      int getLaneId();  // internalLaneId
      int getEquipId();
      int getAlarmId();
      String getDescription();
      String getWoStatus();
      int getWoNumber();
      int getOpenSentFlag();
      int getCloseSentFlag();

   }
