package com.ts.obo.management.device.model;

import lombok.Data;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@Component
@Table(name = "t_moms_work_order")
public class MomsWorkOrder implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    int repairNumber;
    int priority;
    int equipmentId;
    String problemCode;
    int plazaId;
    int laneId;
    long messageId;
    int woNumber;
    String woStatus;
    Date woStartTime;
    Date woEndTime;
    Date updateTs;
    int woId;
    int threshold;
    int resetFrequency;
    int currentCount;
    long currentTsId;
    int currentTod;
    int planTypeId;
    String txStatusId;
    String sendToMoms;

}
