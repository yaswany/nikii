package com.ts.obo.management.device.kafka;

import com.ts.obo.management.device.service.MomsMessageServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class KafkaFileMomsMessageListenerTest {

    @Mock
    private MomsMessageServiceImpl mockMomsMessageService;

    @InjectMocks
    KafkaFileMomsMessageListener KafkaFileMomsMessageListenerTest;

    private String key;

    String message;

    @BeforeEach
    void setUp() {
       // key="ET0204_20211013212349003DNE.zip";
        message= "{\"description\":Plaza distributor job failed,\"agencyId\":6234,\"status\":open,\"plazaId\":114,\"laneId\":867,\"msgCode\":TAG FILE}";

    }

    @Test
    void listenerTest(){

        KafkaFileMomsMessageListenerTest.listen(message);
        verify(mockMomsMessageService, Mockito.atLeastOnce()).insertAndUpdateMomsMessageTx(message);
    }
    @Test
    void listenerTestNullMsg(){

        KafkaFileMomsMessageListenerTest.listen(null);
        verify(mockMomsMessageService, never()).insertAndUpdateMomsMessageTx(null);
    }

}

