package com.ts.obo.management.device.client;


import com.ts.obo.management.device.model.dto.PlazaLaneListDTO;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;


@SpringBootTest(classes=AppClient.class)
@ExtendWith(MockitoExtension.class)
@TestPropertySource("classpath:/application-test.properties")
class AppClientTest {

    @InjectMocks
    @Autowired
    private AppClient appClientTest;

    private  final Logger log = LogManager.getLogger(AppClientTest.class);


    PlazaLaneListDTO plazaLaneListDTO;
    public static MockWebServer mockWebServer;
    static String  laneUrl;

    @BeforeEach
    void setUp() throws IOException {
        mockWebServer = new MockWebServer();
        mockWebServer.start(8080);

        laneUrl = String.format("http://localhost:"+ mockWebServer.getPort()+"/api/obo/admin/plaza/moms/");
       laneUrl = String.format("http://localhost:"+ mockWebServer.getPort()+"/api/obo/admin/plaza/plaza-lane-list/");
    }

    @Test
    void getLanePlazaIdTest() {

        String expected = "200";
        mockWebServer.enqueue(new MockResponse().setBody(expected)
                .addHeader("Content-Type", "application/json").setResponseCode(200));

        ResponseEntity<String> actual = appClientTest.getLanePlazaId();
        Assertions.assertEquals(expected, String.valueOf(actual.getStatusCodeValue()));
    }

    @Test
    void getLaneAndPlazaList() {
//        plazaLaneListDTO= new PlazaLaneListDTO();
//        plazaLaneListDTO.setPlazaId(9);
        String expected = "200";
        mockWebServer.enqueue(new MockResponse().setBody(expected)
                .addHeader("Content-Type", "application/json").setResponseCode(200));
//        List<PlazaLaneListDTO> list =new ArrayList<>();
//        list.add(8,plazaLaneListDTO);
        List<PlazaLaneListDTO> actual = appClientTest.getLaneAndPlazaList();
        log.info("actual"+actual.size());
        Assertions.assertEquals(200, actual.size());
    }
    @Test
    void callMOMSWoOpen() throws Exception {
        String expected = "200";
        mockWebServer.enqueue(new MockResponse().setBody(expected)
                .addHeader("Content-Type", "application/json").setResponseCode(200));
        JSONArray numbers = new JSONArray();
        numbers.put(2);
        RestTemplate result = appClientTest.getRestTemplate();
        JSONObject actual = appClientTest.callMOMSWoOpen("http://138.69.14.132","TEST","3a033302-f43d-4853-86a3-fca78c6e4cf2", numbers);
        Assertions.assertEquals(result, actual);

    }
    @Test
    void callMOMSWoClose() throws Exception {
        String expected = "200";
        mockWebServer.enqueue(new MockResponse().setBody(expected)
                .addHeader("Content-Type", "application/json").setResponseCode(200));
        JSONArray numbers = new JSONArray();
        numbers.put(1);

        JSONObject actual = appClientTest.callMOMSWoClose("http://138.69.14.132/v8","spring","7896", numbers);
        Assertions.assertEquals(expected, actual);

    }

}