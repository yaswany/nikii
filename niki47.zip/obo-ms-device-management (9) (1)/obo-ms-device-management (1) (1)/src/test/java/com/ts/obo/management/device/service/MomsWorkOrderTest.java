package com.ts.obo.management.device.service;


import com.ts.obo.management.device.client.AppClient;
import com.ts.obo.management.device.model.dto.MomsCMMSWorkOrder;

import com.ts.obo.management.device.service.MomsMessageServiceImpl;
import com.ts.obo.management.device.service.MomsWorkOrderService;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.client.RestTemplate;


import java.util.ArrayList;
import java.util.List;

@SpringBootTest(classes = MomsWorkOrderService.class)
@ExtendWith(MockitoExtension.class)
@TestPropertySource("classpath:/application-test.properties")
public class MomsWorkOrderTest {
    @InjectMocks
    @Autowired
    private MomsWorkOrderService momsWorkOrderServiceTest;

    @MockBean
    MomsMessageServiceImpl mockMomsMessageService;
    @MockBean
    AppClient mockAppClient;

    @Value( "${cmms.end.point.url}" )
    private String momsURL;

    @Value( "${cmms.end.point.username}" )
    private String momsUsername;

    @Value( "${cmms.end.point.password}" )
    private String momsPassword;




    @Test
    void getProcessWOCreation() throws Exception {
        String pageSize = "5";
        String pageSizeParam="5";
        MomsCMMSWorkOrder momsTx = new MomsCMMSWorkOrder();
        momsTx.setCloseSentFlag(0);
        momsTx.setOpenSentFlag(1);
        momsTx.setPlazaId(9);
        momsTx.setLaneId(4);
        momsTx.setAlarmId(4);
        momsTx.setDescription("file not found");
        momsTx.setWoStatus("open");
        momsTx.setWoNumber(9);
        momsTx.setExternalLaneId("ETS");
        momsTx.setExternalPlazaId("THF");
        List <MomsCMMSWorkOrder> list = new ArrayList<>();
        list.add(momsTx);
        Mockito.when(mockMomsMessageService.getAllWorkOrders(Integer.parseInt(pageSize))).thenReturn(list);
        momsWorkOrderServiceTest.processWOCreation(pageSizeParam);

    }
    @Test
    void getProcessWOCreationCallMOMSWoOpen() throws Exception {
        String pageSize = "5";
        String pageSizeParam="5";
        MomsCMMSWorkOrder momsTx = new MomsCMMSWorkOrder();
        momsTx.setCloseSentFlag(9);
        momsTx.setOpenSentFlag(0);
        momsTx.setPlazaId(9);
        momsTx.setLaneId(4);
        momsTx.setAlarmId(4);
        momsTx.setDescription("file not found");
        momsTx.setWoStatus("open");
        momsTx.setWoNumber(0);
        momsTx.setExternalLaneId("ETS");
        momsTx.setExternalPlazaId("THF");
        List <MomsCMMSWorkOrder> list = new ArrayList<>();
        list.add(momsTx);
        JSONObject result = new JSONObject();
        result.put("key",1001);
        result.isNull("key"); // returns true, buuuut...
        result.has("key");    // returns false
        result.isNull("somethingIHaventSetAtAll");
        JSONArray numbers = new JSONArray();
        numbers.put(5);
        Mockito.when(mockAppClient.callMOMSWoOpen(momsURL,momsUsername,momsPassword,numbers)).thenReturn(result);
        Mockito.when(mockMomsMessageService.getAllWorkOrders(Integer.parseInt(pageSize))).thenReturn(list);
        momsWorkOrderServiceTest.processWOCreation(pageSizeParam);
        Mockito.verify(mockAppClient,Mockito.atLeastOnce()).callMOMSWoOpen(momsURL,momsUsername,momsPassword,numbers);

    }
    @Test
    void getProcessWOCreationWoNumber() throws Exception {
        String pageSize = "5";
        String pageSizeParam="5";
        MomsCMMSWorkOrder momsTx = new MomsCMMSWorkOrder();
        momsTx.setCloseSentFlag(9);
        momsTx.setOpenSentFlag(1);
        momsTx.setPlazaId(9);
        momsTx.setLaneId(4);
        momsTx.setAlarmId(4);
        momsTx.setDescription("file not found");
        momsTx.setWoStatus("open");
        momsTx.setWoNumber(0);
        momsTx.setExternalLaneId("ETS");
        momsTx.setExternalPlazaId("THF");
        List <MomsCMMSWorkOrder> list = new ArrayList<>();
        list.add(momsTx);
        Mockito.when(mockMomsMessageService.getAllWorkOrders(Integer.parseInt(pageSize))).thenReturn(list);
        momsWorkOrderServiceTest.processWOCreation(pageSizeParam);

    }

}
