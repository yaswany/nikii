package com.ts.obo.management.device.momsMessage;

public class MyException {
}
