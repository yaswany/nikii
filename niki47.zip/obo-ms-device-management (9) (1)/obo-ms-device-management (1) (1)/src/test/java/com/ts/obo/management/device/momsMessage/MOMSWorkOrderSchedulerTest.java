package com.ts.obo.management.device.momsMessage;

import com.ts.obo.management.device.exception.OBOException;
import com.ts.obo.management.device.momsmessage.MOMSWorkOrderScheduler;
import com.ts.obo.management.device.service.MomsWorkOrderService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.mockito.Mockito.verify;
@ExtendWith(SpringExtension.class)
@AutoConfigureMockMvc(addFilters = false)
public class MOMSWorkOrderSchedulerTest {
    @InjectMocks
    MOMSWorkOrderScheduler scheduler;
    @Mock
    private MomsWorkOrderService momsService;

    @Test
    void createWO()
            throws Exception {
        Thread.sleep(10000);
        Mockito.doNothing().when(momsService).processWOCreation(null);
        scheduler.createWO();
        Mockito.verify(momsService).processWOCreation(null);
    }

    @Test
    void createWO1() throws Exception {
        Thread.sleep(10000);
            Mockito.doThrow(NullPointerException.class).when(momsService).processWOCreation(null);
            scheduler.createWO();
            Mockito.verify(momsService).processWOCreation(null);

    }

}


