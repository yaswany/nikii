package com.ts.obo.management.device.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.ts.obo.management.device.client.AppClient;
import com.ts.obo.management.device.exception.ErrorType;
import com.ts.obo.management.device.exception.OBOException;

import com.ts.obo.management.device.model.MomsInsertMessage;
import com.ts.obo.management.device.model.MomsMessage;
import com.ts.obo.management.device.model.MomsMessageMapping;
import com.ts.obo.management.device.model.MomsWorkOrder;
import com.ts.obo.management.device.model.dto.MomsCMMSWorkOrder;
import com.ts.obo.management.device.model.dto.MomsMessageWorkOrders;
import com.ts.obo.management.device.model.dto.PlazaLaneListDTO;
import com.ts.obo.management.device.persistence.MomsMessageMappingRepository;
import com.ts.obo.management.device.persistence.MomsMessageRepository;
import com.ts.obo.management.device.persistence.MomsWorkOrderRepository;
import liquibase.pro.packaged.cA;
import org.json.JSONString;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;


import java.util.*;

import static org.json.XMLTokener.entity;
import static org.mockito.Mockito.*;

@SpringBootTest(classes = MomsMessageServiceImpl.class)
@ExtendWith(MockitoExtension.class)
@TestPropertySource("classpath:/application-test.properties")
class MomsMessageServiceImplTest {

    @Autowired
    @InjectMocks
    MomsMessageServiceImpl momsMessageServiceTest;

    @MockBean
    MomsMessageRepository mockMomsMessageRepository;

    MomsCMMSWorkOrder mockMomsCMMSWorkOrder;
    @MockBean
    MomsWorkOrderRepository mockMomsWorkOrderRepository;

    PlazaLaneListDTO mockPlazaLaneListDTO;
    MomsInsertMessage mockMomsInsertMessage;

    MomsMessageMapping momsMessageMapping;
    MomsMessage mockMomsMessage;
    @MockBean
    MomsMessageMappingRepository mockMomsMessageMappingRepository;

    MomsMessageWorkOrders mockMomsMessageWorkOrders;

    @MockBean
    AppClient mockAppClient;



    //   @ParameterizedTest
//   @ValueSource(ints = {1,2,3,4})

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMomsInsertMessage = new MomsInsertMessage();
        momsMessageMapping = new MomsMessageMapping();
        mockMomsMessage =new MomsMessage();
    }


    @Test
    void updateOpenWO() {
        momsMessageServiceTest.updateOpenWO(10, 3, 12, 34, 9);
        momsMessageServiceTest.updateOpenWO(10, 3, 12, 34, 9);
    }

    @Test
    void updateCloseWO() {
        momsMessageServiceTest.updateCloseWO(10, 3, 12, 34);
        momsMessageServiceTest.updateCloseWO(10, 3, 12, 34);
    }

    @Test
    void updateMomsWorkOrderToCloseWO() {
        MomsWorkOrder momsMessage = new MomsWorkOrder();
        momsMessage.setWoNumber(-1);
        momsMessage.setWoStartTime(null);
        momsMessage.setWoEndTime(null);
        momsMessage.setUpdateTs(new Date());
        momsMessage.setWoStatus(null);
        mockMomsWorkOrderRepository.save(momsMessage);
        Mockito.when(mockMomsWorkOrderRepository.findWorkOrderByIds(Mockito.anyInt(), anyInt(), anyInt(), anyInt())).thenReturn(momsMessage);
        momsMessageServiceTest.updateMomsWorkOrderToCloseWO(10, 3, 12, 34);
    }

    @Test
    void updateMomsWorkOrderToOpenWO() {
        MomsWorkOrder momsMessage = new MomsWorkOrder();
        momsMessage.setWoNumber(34);
        momsMessage.setWoStatus("OPEN");
        momsMessage.setWoStartTime(new Date());
        momsMessage.setWoEndTime(null);
        momsMessage.setUpdateTs(new Date());
        mockMomsWorkOrderRepository.save(momsMessage);
        Mockito.when(mockMomsWorkOrderRepository.findWorkOrderByIds(Mockito.anyInt(), anyInt(), anyInt(), anyInt())).thenReturn(momsMessage);
        momsMessageServiceTest.updateMomsWorkOrderToOpenWO(10, 3, 12, 34, 9);
    }

    @Test
    void setDataAndUpdateMomsStatusClose() {
        MomsMessage momsMessage = new MomsMessage();
        momsMessage.setCloseSentFlag(1);
        momsMessage.setCloseSentTs(new Date());
        momsMessage.setWoEndTime(new Date());
        momsMessage.setWoStatus("CLOSE");
        mockMomsMessageRepository.save(momsMessage);
        Mockito.when(mockMomsMessageRepository.findMomsMessageForCloseWO(Mockito.anyInt(), anyInt(), anyInt(), anyInt())).thenReturn(momsMessage);
        momsMessageServiceTest.updateMomsMessageTxToCloseWO(10, 3, 12, 34);
    }

    @Test
    void setDataAndUpdateMomsStatusOpen() {
        MomsMessage momsMessage = new MomsMessage();
        momsMessage.setWoNumber(89);
        momsMessage.setOpenSentFlag(1);
        momsMessage.setOpenSentTs(new Date());
        momsMessage.setWoStartTime(new Date());
        momsMessage.setWoStatus("OPEN");
        mockMomsMessageRepository.save(momsMessage);
        Mockito.when(mockMomsMessageRepository.findMomsMessageForOpenWO(Mockito.anyInt(), anyInt(), anyInt(), anyInt())).thenReturn(momsMessage);
        momsMessageServiceTest.updateMomsMessageTxToOpenWO(10, 3, 12, 34, 9);
    }

//
//
//    @Test
//    void insertAndUpdateMomsMessageTx() {
//        String result = "{\"description\":\"Plaza distributor job failed\",\"msgCode\":\"TAG FILE\",\"status\":\"open\",\"agencyId\":6234,\"plazaId\":114,\"laneId\":867}";
//        String findMomsByMsgCode = "Plaza distributor job failed-6234";
//        momsMessageMapping.setMsgCode("ETA");
//        momsMessageMapping.setEquipmentId(10);
//        momsMessageMapping.setMsgThreshold(1000);
//        momsMessageMapping.setMsgTimeLimit(10);
//        momsMessageMapping.setRepairNumber(8);
//        mockMomsMessageMappingRepository.save(momsMessageMapping);
//        Mockito.when(mockMomsMessageMappingRepository.findByMsgCode(findMomsByMsgCode)).thenReturn(momsMessageMapping);
//        momsMessageServiceTest.insertAndUpdateMomsMessageTx(result);
//        Mockito.verify(mockMomsMessageMappingRepository.findByMsgCode(findMomsByMsgCode));
//
//    }


    @Test
    void insertAndUpdateMomsMessageTxForOpen() {
        String result = "{\"description\":\"Plaza distributor job failed\",\"msgCode\":\"TAG FILE\",\"status\":\"open\",\"agencyId\":6234,\"plazaId\":9,\"laneId\":867}";
        String findMomsByMsgCode = "Plaza distributor job failed-6234";
        momsMessageMapping.setMsgCode("TAG FILE");
        momsMessageMapping.setEquipmentId(10);
        momsMessageMapping.setMsgThreshold(1000);
        momsMessageMapping.setMsgTimeLimit(10);
        momsMessageMapping.setRepairNumber(8);
        mockMomsMessageMappingRepository.save(momsMessageMapping);
        mockMomsMessage.setAlarmId(9);
        mockMomsMessage.setCloseSentFlag(0);
        mockMomsMessage.setCloseSentTs(new Date());
        mockMomsMessage.setLaneId(89);
        mockMomsMessage.setPlazaId(98);
        mockMomsMessage.setMessageCode("open");
        mockMomsMessage.setMomsTxId(45);
        mockMomsMessage.setUpdateTs(new Date());
        mockMomsMessage.setDescription("file not found");
        mockMomsMessage.setOpenSentFlag(9);
        mockMomsMessage.setUpdateTs(new Date());
        mockMomsMessage.setEquipId(8);
        mockMomsMessageRepository.save(mockMomsMessage);
        Mockito.when(mockMomsMessageRepository.findByMsgCodeForOpen("TAG FILE")).thenReturn(mockMomsMessage);
        Mockito.when(mockMomsMessageMappingRepository.findByMsgCode(findMomsByMsgCode)).thenReturn(momsMessageMapping);
        momsMessageServiceTest.insertAndUpdateMomsMessageTx(result);
        Mockito.verify(mockMomsMessageRepository,Mockito.atLeastOnce()).findByMsgCodeForOpen("TAG FILE");
        Mockito.verify(mockMomsMessageMappingRepository,Mockito.atLeastOnce()).findByMsgCode("Plaza distributor job failed-6234");

    }
    @Test
    void insertAndUpdateMomsMessageTxForClose() {
        String result = "{\"description\":\"Plaza distributor job failed\",\"msgCode\":\"TAG FILE\",\"status\":\"close\",\"agencyId\":6234,\"plazaId\":0,\"laneId\":867}";
        String findMomsByMsgCode = "Plaza distributor job failed-6234";
        momsMessageMapping.setMsgCode("TAG FILE");
        momsMessageMapping.setEquipmentId(10);
        momsMessageMapping.setMsgThreshold(1000);
        momsMessageMapping.setMsgTimeLimit(10);
        momsMessageMapping.setRepairNumber(8);
        mockMomsMessageMappingRepository.save(momsMessageMapping);
        mockMomsMessage.setAlarmId(9);
        mockMomsMessage.setCloseSentFlag(0);
        mockMomsMessage.setCloseSentTs(new Date());
        mockMomsMessage.setLaneId(89);
        mockMomsMessage.setPlazaId(98);
        mockMomsMessage.setMessageCode("");
        mockMomsMessage.setMomsTxId(45);
        mockMomsMessage.setUpdateTs(new Date());
        mockMomsMessage.setDescription("");
        mockMomsMessage.setOpenSentFlag(9);
        mockMomsMessage.setUpdateTs(new Date());
        mockMomsMessage.setEquipId(8);
        mockMomsMessageRepository.save(mockMomsMessage);
        Mockito.when(mockMomsMessageRepository.findByMsgCodeForClose("TAG FILE")).thenReturn(mockMomsMessage);
        Mockito.when(mockMomsMessageMappingRepository.findByMsgCode(findMomsByMsgCode)).thenReturn(momsMessageMapping);
        momsMessageServiceTest.insertAndUpdateMomsMessageTx(result);


    }
    @Test
    void insertAndUpdateMomsMessageTxFindByMsgCode() {
        String result = "{\"description\":\"Plaza distributor job failed\",\"msgCode\":\"TAG FILE\",\"status\":\"close\",\"agencyId\":6234,\"plazaId\":1,\"laneId\":867}";
        String findMomsByMsgCode = "Plaza distributor job failed-6234";
        momsMessageMapping.setMsgCode("ETA");
        momsMessageMapping.setEquipmentId(10);
        momsMessageMapping.setMsgThreshold(1000);
        momsMessageMapping.setMsgTimeLimit(10);
        momsMessageMapping.setRepairNumber(8);
        mockMomsMessageMappingRepository.save(momsMessageMapping);
        Mockito.when(mockMomsMessageMappingRepository.findByMsgCode(findMomsByMsgCode)).thenReturn(momsMessageMapping);
        momsMessageServiceTest.insertAndUpdateMomsMessageTx(result);
        Mockito.verify(mockMomsMessageMappingRepository,Mockito.atLeastOnce()).findByMsgCode("Plaza distributor job failed-6234");

    }
    @Test
    void insertAndUpdateMomsMessageTxGetLanePlazaId() {
        String result = "{\"description\":\"Plaza distributor job failed\",\"msgCode\":\"TAG FILE\",\"status\":\"open\",\"agencyId\":6234,\"plazaId\":0,\"laneId\":867}";
        String findMomsByMsgCode = "Plaza distributor job failed-6234";
       // String JSONString="{\"momsTxId\":89,\"plazaId\":9,\"laneId\":90,\"txDate\":\"dd/MM/yyyy\",\"messageCode\":\"TAG FILE\",\"updateTs\":\"dd/MM/yyyy\",\"sentFlag\":\"open\",\"sentTs\":6234,\"equipId\":90,\"alarmId\":867,\"description\":\"Plaza distributor job failed\",\"woNumber\":98,\"woStatus\":\"open\",\"openSentFlag\":6234,\"closeSentFlag\":0,\"openSentTs\":\"dd/MM/yyyy\",\"closeSentTs\":\"dd/MM/yyyy\",\"woStartTime\":\"dd/MM/yyyy\",\"woEndTime\":\"dd/MM/yyyy\"}";
        momsMessageMapping.setMsgCode("ETA");
        momsMessageMapping.setEquipmentId(10);
        momsMessageMapping.setMsgThreshold(1000);
        momsMessageMapping.setMsgTimeLimit(10);
        momsMessageMapping.setRepairNumber(8);
        mockMomsMessageMappingRepository.save(momsMessageMapping);
        var momsMessage = new MomsMessage();
        momsMessage.setMomsTxId(78);
        momsMessage.setLaneId(9);
        momsMessage.setPlazaId(9);
        momsMessage.setAlarmId(1);
        momsMessage.setUpdateTs(new Date());
        Mockito.when(mockMomsMessageMappingRepository.findByMsgCode(findMomsByMsgCode)).thenReturn(momsMessageMapping);
        String response = "{ \"laneId\" : 9, \"plazaId\" : 9, \"httpStatusCode\" : 200}";
        ResponseEntity<String> responseEntity = new ResponseEntity(response, HttpStatus.OK);
        Mockito.when(mockAppClient.getLanePlazaId()).thenReturn(responseEntity);
        momsMessageServiceTest.insertAndUpdateMomsMessageTx(result);
        Mockito.verify(mockAppClient, Mockito.atLeastOnce()).getLanePlazaId();

    }
    @Test
    void findByMsgCodeForStatusOpen() {
        String result = "{\"description\":\"Plaza distributor job failed\",\"msgCode\":\"TAG FILE\",\"status\":\"open\",\"agencyId\":6234,\"plazaId\":0,\"laneId\":867}";
        String findMomsByMsgCode = "Plaza distributor job failed-6234";
        // String JSONString="{\"momsTxId\":89,\"plazaId\":9,\"laneId\":90,\"txDate\":\"dd/MM/yyyy\",\"messageCode\":\"TAG FILE\",\"updateTs\":\"dd/MM/yyyy\",\"sentFlag\":\"open\",\"sentTs\":6234,\"equipId\":90,\"alarmId\":867,\"description\":\"Plaza distributor job failed\",\"woNumber\":98,\"woStatus\":\"open\",\"openSentFlag\":6234,\"closeSentFlag\":0,\"openSentTs\":\"dd/MM/yyyy\",\"closeSentTs\":\"dd/MM/yyyy\",\"woStartTime\":\"dd/MM/yyyy\",\"woEndTime\":\"dd/MM/yyyy\"}";
        momsMessageMapping.setMsgCode("ETA");
        momsMessageMapping.setEquipmentId(10);
        momsMessageMapping.setMsgThreshold(1000);
        momsMessageMapping.setMsgTimeLimit(10);
        momsMessageMapping.setRepairNumber(8);
        mockMomsMessageMappingRepository.save(momsMessageMapping);
        var momsMessage = new MomsMessage();
        momsMessage.setMomsTxId(78);
        momsMessage.setLaneId(9);
        momsMessage.setPlazaId(9);
        momsMessage.setAlarmId(1);
        momsMessage.setUpdateTs(new Date());
        Mockito.when(mockMomsMessageMappingRepository.findByMsgCode(findMomsByMsgCode)).thenReturn(momsMessageMapping);
        momsMessageServiceTest.insertAndUpdateMomsMessageTx(result);
        Mockito.verify(mockMomsMessageMappingRepository,Mockito.atLeastOnce()).findByMsgCode(findMomsByMsgCode);

    }
    @Test
    void findByMsgCodeForStatusOpenAndPlazaId() {
        String result = "{\"description\":\"Plaza distributor job failed\",\"msgCode\":\"TAG FILE\",\"status\":\"open\",\"agencyId\":6234,\"plazaId\":0,\"laneId\":867}";
        String findMomsByMsgCode = "Plaza distributor job failed-6234";
        // String JSONString="{\"momsTxId\":89,\"plazaId\":9,\"laneId\":90,\"txDate\":\"dd/MM/yyyy\",\"messageCode\":\"TAG FILE\",\"updateTs\":\"dd/MM/yyyy\",\"sentFlag\":\"open\",\"sentTs\":6234,\"equipId\":90,\"alarmId\":867,\"description\":\"Plaza distributor job failed\",\"woNumber\":98,\"woStatus\":\"open\",\"openSentFlag\":6234,\"closeSentFlag\":0,\"openSentTs\":\"dd/MM/yyyy\",\"closeSentTs\":\"dd/MM/yyyy\",\"woStartTime\":\"dd/MM/yyyy\",\"woEndTime\":\"dd/MM/yyyy\"}";
        momsMessageMapping.setMsgCode("ETA");
        momsMessageMapping.setEquipmentId(10);
        momsMessageMapping.setMsgThreshold(1000);
        momsMessageMapping.setMsgTimeLimit(10);
        momsMessageMapping.setRepairNumber(8);
        mockMomsMessageMappingRepository.save(momsMessageMapping);
        var momsMessage = new MomsMessage();
        momsMessage.setMomsTxId(78);
        momsMessage.setLaneId(9);
        momsMessage.setPlazaId(9);
        momsMessage.setAlarmId(1);
        momsMessage.setUpdateTs(new Date());
        Mockito.when(mockMomsMessageMappingRepository.findByMsgCode(findMomsByMsgCode)).thenReturn(momsMessageMapping);
        momsMessageServiceTest.insertAndUpdateMomsMessageTx(result);
        Mockito.verify(mockMomsMessageMappingRepository,Mockito.atLeastOnce()).findByMsgCode("Plaza distributor job failed-6234");

    }

    @Test
    void insertAndUpdateMomsMessageStatusOpenAndPlazaId() {
        String result = "{\"description\":\"Plaza distributor job failed\",\"msgCode\":\"FILE\",\"status\":\"open\",\"agencyId\":6234,\"plazaId\":114,\"laneId\":867}";
        String findMomsByMsgCode = "Plaza distributor job failed";
        momsMessageMapping.setMsgCode("ETA");
        momsMessageMapping.setEquipmentId(10);
        momsMessageMapping.setMsgThreshold(1000);
        momsMessageMapping.setMsgTimeLimit(10);
        momsMessageMapping.setRepairNumber(8);
        mockMomsMessageMappingRepository.save(momsMessageMapping);
        Mockito.when(mockMomsMessageMappingRepository.findByMsgCode(findMomsByMsgCode)).thenReturn(momsMessageMapping);
        momsMessageServiceTest.insertAndUpdateMomsMessageTx(result);
        Mockito.verify(mockMomsMessageMappingRepository,Mockito.atLeastOnce()).findByMsgCode(findMomsByMsgCode);

    }


    @Test
    void getAllWorkOrder() {
        mockMomsCMMSWorkOrder = new MomsCMMSWorkOrder();
        mockMomsCMMSWorkOrder.setCloseSentFlag(0);
        mockMomsCMMSWorkOrder.setOpenSentFlag(1);
        mockMomsCMMSWorkOrder.setPlazaId(9);
        mockMomsCMMSWorkOrder.setLaneId(4);
        mockMomsCMMSWorkOrder.setAlarmId(4);
        mockMomsCMMSWorkOrder.setDescription("file not found");
        mockMomsCMMSWorkOrder.setWoStatus("open");
        mockMomsCMMSWorkOrder.setWoNumber(9);
        mockMomsCMMSWorkOrder.setExternalLaneId("ETS");
        mockMomsCMMSWorkOrder.setExternalPlazaId("THF");

        mockPlazaLaneListDTO = new PlazaLaneListDTO();
        mockPlazaLaneListDTO.setPlazaId(98);
        mockPlazaLaneListDTO.setLaneId(76);
        mockPlazaLaneListDTO.setExternLaneId("ETS");
        mockPlazaLaneListDTO.setName("");
        mockPlazaLaneListDTO.setExternPlazaId("THF");
        List<PlazaLaneListDTO> lanePlazaList = new ArrayList<>();
        lanePlazaList.add(mockPlazaLaneListDTO);
        List<MomsCMMSWorkOrder> list = new ArrayList<>();
        list.add(mockMomsCMMSWorkOrder);
        Mockito.when(mockAppClient.getLaneAndPlazaList()).thenReturn(lanePlazaList);
        momsMessageServiceTest.getAllWorkOrders(5);
        Mockito.verify(mockAppClient,Mockito.atLeastOnce()).getLaneAndPlazaList();
    }
}
