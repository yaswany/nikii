package com.ts.obo.management.device.exception;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;


@ExtendWith(MockitoExtension.class)
public class OBORestResponseExceptionHandlerTest {
    @InjectMocks
    @Autowired
    private OBORestResponseExceptionHandler oboRestResponseExceptionHandler;

    private OBORestErrorResponse oboRestErrorResponse;


    @Test
    void testNoArgConstructor(){
        oboRestResponseExceptionHandler = new OBORestResponseExceptionHandler();
        Assertions.assertInstanceOf(OBORestResponseExceptionHandler.class,oboRestResponseExceptionHandler);
    }

    @Test
    void testNoArgConstructor1(){
        Exception NullPointerException = new Exception();
        oboRestErrorResponse=new OBORestErrorResponse();
        oboRestErrorResponse.setTimestamp(LocalDateTime.now());
        oboRestErrorResponse.setMessage(null);
        oboRestErrorResponse.setType("OBOException");
        oboRestErrorResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
        ResponseEntity<Object> response =new ResponseEntity(oboRestErrorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        ResponseEntity<Object> actual = oboRestResponseExceptionHandler.handleException(NullPointerException);
        Assertions.assertEquals(response.getStatusCode(), actual.getStatusCode());
    }


}
