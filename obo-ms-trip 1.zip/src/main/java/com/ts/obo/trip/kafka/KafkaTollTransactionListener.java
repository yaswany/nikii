package com.ts.obo.trip.kafka;

import com.ts.obo.trip.service.MessageService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;

import org.springframework.stereotype.Component;

/**
 * The type Kafka file name listener.
 */
@Slf4j
@Component
public class KafkaTollTransactionListener {

    @Autowired
    private MessageService messageService;

    @KafkaListener(topics = "${kafka.topic_name}", groupId = "${kafka.group_id}", containerFactory = "containerFactory")
    public void listen(String message, Acknowledgment ack) throws Exception {
        try{
            log.info("LISTENER : KafkaDBQueueListener : message {}",message);
            messageService.processMessage(message);
            ack.acknowledge();
            log.info("acknowledge successfully !!!");
        }catch (Exception e){
            log.error("error while processing the incoming kafka messages",e);
        }
    }
}