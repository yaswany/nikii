package com.ts.obo.trip.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "t_tripfare_details")
public class TripfareDetails implements Serializable {

    @Id
    private Integer tripId;
    @Id
    private Integer segmentId;
    private Integer agencyId;
    private float chargedDistance;
    private float postedRate;
    private Date fareTs;
    private float computedFare;
    private Integer rateId;
    private String  fareType;
    private float dmsFareUsed;
    private float altFare;
    private Date appliedTxnTs;
    private Date updateTs;

}
