package com.ts.obo.trip.persistence.nosql;

import com.ts.obo.trip.model.TripCheckpoint;
import com.ts.obo.trip.model.TripInfo;
import com.ts.obo.trip.persistence.TripCheckpointRepository;
import com.ts.obo.trip.persistence.TripInfoRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Qualifier("TripInfoRepository")
@Repository
public interface TripInfoNoSqlRepository extends CrudRepository<TripInfo, String>, TripInfoRepository {
}