package com.ts.obo.trip.persistence;


import com.ts.obo.trip.model.TripTx;
import com.ts.obo.trip.model.dto.DateList;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.Date;
import java.util.List;

@NoRepositoryBean
public interface TripTxRepository extends ITransportationRepository<TripTx, Long> {

    @Query(nativeQuery = true)
    Date getEntryTxDate(int agencyId);

    @Query(nativeQuery = true)
    Date getMaxEntryTxDate(Date entryTxDate,int agencyId);

    @Query
    List<DateList> getDatesList(Date startDate, Date endDate);
}