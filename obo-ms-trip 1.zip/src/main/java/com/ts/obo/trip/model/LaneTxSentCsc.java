package com.ts.obo.trip.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "t_lane_tx_sent_csc")
public class LaneTxSentCsc implements Serializable {

    @Id
    private Integer laneTxId;
    private Integer messageId;
    private Date sentDate;
    private Integer cscSendFileId;
    private Integer cscRecvFileId;
    private float amtColl;
    private Integer planType;
    private Integer cscViolStatus;
    private Date postedDate;
    private String isImageAvail;
    private Date updateTs;
    private Integer etcTxStatus;
    private Integer plazaGroup;
    private Integer extraAxles;
    private float ezpassAmount;
    private float ezpassAmountDis1;
    private float ezpassAmountDis2;
    private Integer overSpeed;
    private float videoAmount;
    private String classCharged;

}
