package com.ts.obo.trip.model.kafka;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import com.ts.obo.trip.util.CustomJsonDateDeserializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JacksonXmlRootElement(localName = "TollTransaction")
public class TollTransaction {


    @JsonProperty(value = "VehicleSequenceNo")
    @JacksonXmlProperty(localName = "VehicleSequenceNo")
    private String vehicleSequenceNo;           //VehSequenceNoType - String

    @JsonProperty(value = "Loop1TimeStamp")
    @JacksonXmlProperty(localName = "Loop1TimeStamp")
    @JsonDeserialize(using = CustomJsonDateDeserializer.class)
    private Long loop1TimeStamp;                //dateTime - Long

    @JsonProperty(value = "Loop2TimeStamp")
    @JacksonXmlProperty(localName = "Loop2TimeStamp")
    @JsonDeserialize(using = CustomJsonDateDeserializer.class)
    private Long loop2TimeStamp;                //dateTime - Long

    @JsonProperty(value = "Loop3TimeStamp")
    @JacksonXmlProperty(localName = "Loop3TimeStamp")
    @JsonDeserialize(using = CustomJsonDateDeserializer.class)
    private Long loop3TimeStamp;                //dateTime - Long

    @JsonProperty(value = "Loop4TimeStamp")
    @JacksonXmlProperty(localName = "Loop4TimeStamp")
    @JsonDeserialize(using = CustomJsonDateDeserializer.class)
    private Long loop4TimeStamp;                //dateTime - Long

    // --> AVC -->
    @JsonProperty(value = "PostClass")
    @JacksonXmlProperty(localName = "PostClass")
    private Integer postClass;                  //ClassType - INT

    @JsonProperty(value = "AvcMappedClass")
    @JacksonXmlProperty(localName = "AvcMappedClass")
    private Integer avcMappedClass;             //ClassType - INT

    @JsonProperty(value = "PostAxle")
    @JacksonXmlProperty(localName = "PostAxle")
    private Integer postAxle;                   //AxleType - INT

    @JsonProperty(value = "AvcMappedAxle")
    @JacksonXmlProperty(localName = "AvcMappedAxle")
    private Integer avcMappedAxle;              //AxleType - INT

    @JsonProperty(value = "Straddling")
    @JacksonXmlProperty(localName = "Straddling")
    private Integer straddling;                 //StraddlingType -INT

    @JsonProperty(value = "Speed")
    @JacksonXmlProperty(localName = "Speed")
    private Integer speed;                      //SpeedType - INT

    @JsonProperty(value = "AviTagReadTime")
    @JacksonXmlProperty(localName = "AviTagReadTime")
    @JsonDeserialize(using = CustomJsonDateDeserializer.class)
    private Long aviTagReadTime;                //dateTime - Long

    // --> AVI -->
    // --> IAG -->
    @JsonProperty(value = "TagIagClass")
    @JacksonXmlProperty(localName = "TagIagClass")
    private Integer tagIagClass;                //IagClassType - INT

    @JsonProperty(value = "AviIagMappedClass")
    @JacksonXmlProperty(localName = "AviIagMappedClass")
    private Integer aviIagMappedClass;          //ClassType - INT

    // --> SeGO -->
    @JsonProperty(value = "AviSegoRawClass")
    @JacksonXmlProperty(localName = "AviSegoRawClass")
    private Integer aviSegoRawClass;            //IagClassType - INT

    @JsonProperty(value = "AviSegoMappedClass")
    @JacksonXmlProperty(localName = "AviSegoMappedClass")
    private Integer aviSegoMappedClass;         //ClassType - INT

    // --> AVI Combined -->
    @JsonProperty(value = "AviClass")
    @JacksonXmlProperty(localName = "AviClass")
    private Integer aviClass;                   //ClassType - INT

    @JsonProperty(value = "AviClass2")
    @JacksonXmlProperty(localName = "AviClass2")
    private Integer aviClass2;                  //ClassType - INT

    @JsonProperty(value = "AviAxle")
    @JacksonXmlProperty(localName = "AviAxle")
    private Integer aviAxle;                    //AxleType - INT

    @JsonProperty(value = "AviStraddling")
    @JacksonXmlProperty(localName = "AviStraddling")
    private Integer aviStraddling;              //StraddlingType -INT

    // --> Tag Status -->
    @JsonProperty(value = "TagInstitution")
    @JacksonXmlProperty(localName = "TagInstitution")
    private String tagInstitution;              //TagInstitutionType - String

    @JsonProperty(value = "TagNumber")
    @JacksonXmlProperty(localName = "TagNumber")
    private String tagNumber;                   //TagNumberType - String

    @JsonProperty(value = "TagStatus")
    @JacksonXmlProperty(localName = "TagStatus")
    private String tagStatus;                   //TagStatusType - String

    @JsonProperty(value = "AccountStatus")
    @JacksonXmlProperty(localName = "AccountStatus")
    private String accountStatus;               //AccountStatusType - String

    @JsonProperty(value = "Title21TagType")
    @JacksonXmlProperty(localName = "Title21TagType")
    private Integer title21TagType;             //Title21TagTypeType - INT

    @JsonProperty(value = "Title21TagType_2")
    @JacksonXmlProperty(localName = "Title21TagType_2")
    private Integer title21TagType2;           //Title21TagTypeType - INT

    @JsonProperty(value = "TagSwitchPosition")
    @JacksonXmlProperty(localName = "TagSwitchPosition")
    private String tagSwitchPosition;           //TagSwitchPositionType - String

    @JsonProperty(value = "DigitalSwitchPosition")
    @JacksonXmlProperty(localName = "DigitalSwitchPosition")
    private String digitalSwitchPosition;       //DigitalSwitchPositionType - String

    @JsonProperty(value = "FinalSwitchPosition")
    @JacksonXmlProperty(localName = "FinalSwitchPosition")
    private String finalSwitchPosition;         //FinalSwitchPositionType - String

    // --> ScannerHeight -->
    @JsonProperty(value = "VehicleHeight")
    @JacksonXmlProperty(localName = "VehicleHeight")
    private String vehicleHeight;               //VehicleHeightType - String

    @JsonProperty(value = "ScannerVehicleUnits")
    @JacksonXmlProperty(localName = "ScannerVehicleUnits")
    private Integer scannerVehicleUnits;        //ScannerVehicleUnitsType - INT

    @JsonProperty(value = "ScannerMappedClass")
    @JacksonXmlProperty(localName = "ScannerMappedClass")
    private Integer scannerMappedClass;         //ClassType - INT

    // --> TX Characterization -->
    @JsonProperty(value = "ImageTaken")
    @JacksonXmlProperty(localName = "ImageTaken")
    private String imageTaken;                  //ImageTakenType - String

    @JsonProperty(value = "MisClass")
    @JacksonXmlProperty(localName = "MisClass")
    private String misClass;                    //MisClassType - String

    @JsonProperty(value = "AvcOrScannerMappedClass")
    @JacksonXmlProperty(localName = "AvcOrScannerMappedClass")
    private Integer avcOrScannerMappedClass;    //ClassType - INT

    @JsonProperty(value = "ActualClass")
    @JacksonXmlProperty(localName = "ActualClass")
    private Integer actualClass;                //ClassType - INT

    @JsonProperty(value = "ActualAxle")
    @JacksonXmlProperty(localName = "ActualAxle")
    private Integer actualAxle;                 //AxleType - INT

    @JsonProperty(value = "PayType")
    @JacksonXmlProperty(localName = "PayType")
    private String payType;                     //PaymentType - String

    @JsonProperty(value = "PreAxle")
    @JacksonXmlProperty(localName = "PreAxle")
    private Integer preAxle;                    //AxleType - INT

    @JsonProperty(value = "AmountDue")
    @JacksonXmlProperty(localName = "AmountDue")
    private Integer amountDue;                  //AmountType - INT

    @JsonProperty(value = "AmountPaid")
    @JacksonXmlProperty(localName = "AmountPaid")
    private Integer amountPaid;                 //AmountType - INT

    @JsonProperty(value = "ForwardAxle")
    @JacksonXmlProperty(localName = "ForwardAxle")
    private Integer forwardAxle;                //AxleType - INT

    @JsonProperty(value = "CollectorAxle")
    @JacksonXmlProperty(localName = "CollectorAxle")
    private Integer collectorAxle;              //AxleType - INT

    @JsonProperty(value = "ReverseAxle")
    @JacksonXmlProperty(localName = "ReverseAxle")
    private Integer reverseAxle;                //AxleType - INT

    @JsonProperty(value = "UnknownAxle")
    @JacksonXmlProperty(localName = "UnknownAxle")
    private Integer unknownAxle;                //AxleType - INT

    @JsonProperty(value = "ExitGateOpenReason")
    @JacksonXmlProperty(localName = "ExitGateOpenReason")
    private String exitGateOpenReason;          //String

    @JsonProperty(value = "TurnAroundReceipt")
    @JacksonXmlProperty(localName = "TurnAroundReceipt")
    private Integer turnAroundReceipt;          //INT

    @JsonProperty(value = "TagReadCount")
    @JacksonXmlProperty(localName = "TagReadCount")
    private Integer tagReadCount;               //INT

    @JsonProperty(value = "AmmLevel")
    @JacksonXmlProperty(localName = "AmmLevel")
    private Integer ammLevel;                   //INT

    @JsonProperty(value = "TagWriteStatus")
    @JacksonXmlProperty(localName = "TagWriteStatus")
    private Integer tagWriteStatus;             //INT

    @JsonProperty(value = "TagCollectorAxle")
    @JacksonXmlProperty(localName = "TagCollectorAxle")
    private Integer tagCollectorAxle;           //AxleType - INT

    @JsonProperty(value = "BarcodeNumber")
    @JacksonXmlProperty(localName = "BarcodeNumber")
    private Integer barcodeNumber;              //INT

    @JsonProperty(value = "BarcodeStatus")
    @JacksonXmlProperty(localName = "BarcodeStatus")
    private Integer barcodeStatus;              //INT

    @JsonProperty(value = "Keystrokes")
    @JacksonXmlProperty(localName = "Keystrokes")
    private String keystrokes;                  //KeystrokesType - String

    @JsonProperty(value = "ValutHousing")
    @JacksonXmlProperty(localName = "ValutHousing")
    private Integer valutHousing;               //INT

    @JsonProperty(value = "VaultId")
    @JacksonXmlProperty(localName = "VaultId")
    private Integer vaultId;                    //VaultIdType - INT

    @JsonProperty(value = "BillsAccepted")
    @JacksonXmlProperty(localName = "BillsAccepted")
    private Integer billsAccepted;              //BillsAcceptedType - INT

    @JsonProperty(value = "CoinsDispensed")
    @JacksonXmlProperty(localName = "CoinsDispensed")
    private Integer coinsDispensed;             //CoinsDispensedType - INT

    @JsonProperty(value = "CardId")
    @JacksonXmlProperty(localName = "CardId")
    private String cardId;                      //CardIdType - String

    @JsonProperty(value = "EntryPlazaId")
    @JacksonXmlProperty(localName = "EntryPlazaId")
    private String entryPlazaId;                //PlazaIdType - String

    @JsonProperty(value = "EntryLaneId")
    @JacksonXmlProperty(localName = "EntryLaneId")
    private String entryLaneId;                 //LaneIdType - String

    @JsonProperty(value = "TravelDirection")
    @JacksonXmlProperty(localName = "TravelDirection")
    private String travelDirection;             //TravelDirection - String

    @JsonProperty(value = "EntryDateTime")
    @JacksonXmlProperty(localName = "EntryDateTime")
    @JsonDeserialize(using = CustomJsonDateDeserializer.class)
    private Long entryDateTime;                 //dateTime - Long

    @JsonProperty(value = "DeviceWeightClass")
    @JacksonXmlProperty(localName = "DeviceWeightClass")
    private String deviceWeightClass;           //DeviceWeightClassType - String

    @JsonProperty(value = "DeviceEncodedRev")
    @JacksonXmlProperty(localName = "DeviceEncodedRev")
    private String deviceEncodedRev;            //DeviceEncodedRevType - String

    @JsonProperty(value = "DeviceEncodedRev2")
    @JacksonXmlProperty(localName = "DeviceEncodedRev2")
    private String deviceEncodedRev2;            //DeviceEncodedRevType2 - String

    @JsonProperty(value = "DeviceMountLocation")
    @JacksonXmlProperty(localName = "DeviceMountLocation")
    private String deviceMountLocation;         //DeviceMountLocationType - String

    @JsonProperty(value = "PreClass")
    @JacksonXmlProperty(localName = "PreClass")
    private Integer preClass;                   //ClassType - INT

    @JsonProperty(value = "CollectorClass")
    @JacksonXmlProperty(localName = "CollectorClass")
    private Integer collectorClass;             //ClassType - INT

    @JsonProperty(value = "FareClass")
    @JacksonXmlProperty(localName = "FareClass")
    private Integer fareClass;                  //ClassType - INT

    @JsonProperty(value = "PreAxles")
    @JacksonXmlProperty(localName = "PreAxles")
    private Integer preAxles;                   //AxleType - INT

    @JsonProperty(value = "PostAxles")
    @JacksonXmlProperty(localName = "PostAxles")
    private Integer postAxles;                  //AxleType - INT

    @JsonProperty(value = "CollectorAxles")
    @JacksonXmlProperty(localName = "CollectorAxles")
    private Integer collectorAxles;             //AxleType - INT

    @JsonProperty(value = "TicketTransportId")
    @JacksonXmlProperty(localName = "TicketTransportId")
    private Integer ticketTransportId;          //TicketTransportIdType - INT

    @JsonProperty(value = "OverrideFare")
    @JacksonXmlProperty(localName = "OverrideFare")
    private Integer overrideFare;               //AmountType - INT

    @JsonProperty(value = "TollFareId")
    @JacksonXmlProperty(localName = "TollFareId")
    private Integer tollFareId;                 //TollFareIdType - INT

    @JsonProperty(value = "MUTRefId")
    @JacksonXmlProperty(localName = "MUTRefId")
    private Integer mutRefId;                   //MUTRefIdType - INT

    @JsonProperty(value = "CoinDollar")
    @JacksonXmlProperty(localName = "CoinDollar")
    private Integer coinDollar;                 //ATPMDetectedType - INT

    @JsonProperty(value = "Coin50")
    @JacksonXmlProperty(localName = "Coin50")
    private Integer coin50;                     //ATPMDetectedType - INT

    @JsonProperty(value = "Coin25")
    @JacksonXmlProperty(localName = "Coin25")
    private Integer coin25;                     //ATPMDetectedType - INT

    @JsonProperty(value = "Coin10")
    @JacksonXmlProperty(localName = "Coin10")
    private Integer coin10;                     //ATPMDetectedType - INT

    @JsonProperty(value = "Coin5")
    @JacksonXmlProperty(localName = "Coin5")
    private Integer coin5;                      //ATPMDetectedType - INT

    @JsonProperty(value = "Coin1")
    @JacksonXmlProperty(localName = "Coin1")
    private Integer coin1;                      //ATPMDetectedType - INT

    @JsonProperty(value = "Bill100")
    @JacksonXmlProperty(localName = "Bill100")
    private Integer bill100;                    //ATPMDetectedType - INT

    @JsonProperty(value = "Bill50")
    @JacksonXmlProperty(localName = "Bill50")
    private Integer bill50;                     //ATPMDetectedType - INT

    @JsonProperty(value = "Bill20")
    @JacksonXmlProperty(localName = "Bill20")
    private Integer bill20;                     //ATPMDetectedType - INT

    @JsonProperty(value = "Bill10")
    @JacksonXmlProperty(localName = "Bill10")
    private Integer bill10;                     //ATPMDetectedType - INT

    @JsonProperty(value = "Bill5")
    @JacksonXmlProperty(localName = "Bill5")
    private Integer bill5;                      //ATPMDetectedType - INT

    @JsonProperty(value = "Bill2")
    @JacksonXmlProperty(localName = "Bill2")
    private Integer bill2;                      //ATPMDetectedType - INT

    @JsonProperty(value = "Bill1")
    @JacksonXmlProperty(localName = "Bill1")
    private Integer bill1;                      //ATPMDetectedType - INT

    @JsonProperty(value = "VaultPosition")
    @JacksonXmlProperty(localName = "VaultPosition")
    private Integer vaultPosition;              //VaultPositionType - INT

    @JsonProperty(value = "TagProtocol")
    @JacksonXmlProperty(localName = "TagProtocol")
    private String tagProtocol;                 //TagProtocolType - String

    @JsonProperty(value = "TagInstitution2")
    @JacksonXmlProperty(localName = "TagInstitution2")
    private String tagInstitution2;             //TagInstitutionType - String

    @JsonProperty(value = "TagNumber2")
    @JacksonXmlProperty(localName = "TagNumber2")
    private String tagNumber2;                  //TagNumberType - String

    @JsonProperty(value = "TagStatus2")
    @JacksonXmlProperty(localName = "TagStatus2")
    private String tagStatus2;                  //TagStatusType - String

    @JsonProperty(value = "AccountStatus2")
    @JacksonXmlProperty(localName = "AccountStatus2")
    private String accountStatus2;              //AccountStatusType - String

    @JsonProperty(value = "TagProtocol2")
    @JacksonXmlProperty(localName = "TagProtocol2")
    private String tagProtocol2;                //TagProtocolType - String

    // --> ScannerHeight -->
    @JsonProperty(value = "OverHeightCondition")
    @JacksonXmlProperty(localName = "OverHeightCondition")
    private Integer overHeightCondition;        //OverHeightConditionType - INT

    @JsonProperty(value = "PreScannerHeight")
    @JacksonXmlProperty(localName = "PreScannerHeight")
    private Integer preScannerHeight;           //ScannerHeightType - INT

    @JsonProperty(value = "PostScannerHeight")
    @JacksonXmlProperty(localName = "PostScannerHeight")
    private Integer postScannerHeight;          //ScannerHeightType - INT

    @JsonProperty(value = "ScannerFirstAxleHeight")
    @JacksonXmlProperty(localName = "ScannerFirstAxleHeight")
    private Integer scannerFirstAxleHeight;     //ScannerHeightType - INT

    @JsonProperty(value = "ScannerClass")
    @JacksonXmlProperty(localName = "ScannerClass")
    private Integer scannerClass;               //ClassType - INT

    // --> TX Characterization -->
    @JsonProperty(value = "LastFourDigits")
    @JacksonXmlProperty(localName = "LastFourDigits")
    private Integer lastFourDigits;             //CreditCardNumberType - INT

    @JsonProperty(value = "CreditCardType")
    @JacksonXmlProperty(localName = "CreditCardType")
    private String creditCardType;              //CreditCardType - String

    @JsonProperty(value = "AuthCode")
    @JacksonXmlProperty(localName = "AuthCode")
    private String authCode;                    //CreditCardAuthType - String

    @JsonProperty(value = "EntryTransactionTime")
    @JacksonXmlProperty(localName = "EntryTransactionTime")
    @JsonDeserialize(using = CustomJsonDateDeserializer.class)
    private Long entryTransactionTime;          //dateTime - Long

    @JsonProperty(value = "TicketNumber")
    @JacksonXmlProperty(localName = "TicketNumber")
    private String ticketNumber;                //TicketNumberTpe - String

    @JsonProperty(value = "UOCode")
    @JacksonXmlProperty(localName = "UOCode")
    private String uoCode;                      //UOCodeType - String

    @JsonProperty(value = "TagFileTimestamp")
    @JacksonXmlProperty(localName = "TagFileTimestamp")
    private String tagFileTimestamp;            //TagFileTimeStampType - String

    @JsonProperty(value = "IncrementalTagTimestamp")
    @JacksonXmlProperty(localName = "IncrementalTagTimestamp")
    private String incrementalTagTimestamp;     //TagFileTimeStampType - String

}

