package com.ts.obo.trip.model.kafka;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import com.ts.obo.trip.util.CustomJsonDateDeserializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JacksonXmlRootElement(localName = "LaneMessage")
public class LaneMessage {

    @JsonIgnore
    private Long messageId;

    @JsonProperty(value = "MessageSequenceNo")
    @JacksonXmlProperty(localName = "MessageSequenceNo")
    private Integer messageSequenceNo;		//SequenceNoType - INT

    @JsonProperty(value = "PlazaId")
    @JacksonXmlProperty(localName = "PlazaId")
    private String plazaId;            		//PlazaIdType - String

    @JsonProperty(value = "LaneId")
    @JacksonXmlProperty(localName = "LaneId")
    private String laneId;            		//LaneIdType - String

    @JsonProperty(value = "TollTransaction")
    @JacksonXmlProperty(localName = "TollTransaction")
    private TollTransaction tollTransaction;

    @JsonProperty(value = "RecordType")
    @JacksonXmlProperty(localName = "RecordType")
    private Integer recordType;            	//ValidLaneMessagesTypes - INT

    @JsonProperty(value = "TxnTime")
    @JacksonXmlProperty(localName = "TxnTime")
    @JsonDeserialize(using = CustomJsonDateDeserializer.class)
    private Long txnTime;

    @JsonProperty(value = "RecordSubType")
    @JacksonXmlProperty(localName = "RecordSubType")
    private Integer recordSubType;           //ValidLaneMessagesSubTypes - INT
}

