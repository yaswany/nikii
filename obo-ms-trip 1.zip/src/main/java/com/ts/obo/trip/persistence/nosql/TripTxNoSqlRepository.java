package com.ts.obo.trip.persistence.nosql;

import com.ts.obo.trip.model.TripInfo;
import com.ts.obo.trip.model.TripTx;
import com.ts.obo.trip.persistence.TripInfoRepository;
import com.ts.obo.trip.persistence.TripTxRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Qualifier("TripTxRepository")
@Repository
public interface TripTxNoSqlRepository extends CrudRepository<TripTx, Long>, TripTxRepository {
}