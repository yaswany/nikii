package com.ts.obo.trip.model.dto;

public interface ViolationImageInfo {

    int getViolImgTakenCount();
    int getViolImgRecCount();
    int getViolImgRevCount();
}
