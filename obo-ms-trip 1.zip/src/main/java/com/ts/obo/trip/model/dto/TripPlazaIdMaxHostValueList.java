package com.ts.obo.trip.model.dto;

import java.util.Date;

public interface TripPlazaIdMaxHostValueList {

    long getPlazaId();
    long getMaxHostValue();
    Date getUpdateTimestamp();
}
