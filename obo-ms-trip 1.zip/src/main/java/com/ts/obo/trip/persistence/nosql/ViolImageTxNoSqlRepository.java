package com.ts.obo.trip.persistence.nosql;

import com.ts.obo.trip.model.TripInfo;
import com.ts.obo.trip.model.ViolImageTx;
import com.ts.obo.trip.persistence.ViolImageTxRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Qualifier("ViolImageTxRepository")
@Repository
public interface ViolImageTxNoSqlRepository extends CrudRepository<ViolImageTx, Long>, ViolImageTxRepository {
}