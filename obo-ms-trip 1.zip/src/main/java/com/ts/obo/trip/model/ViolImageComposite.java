package com.ts.obo.trip.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Date;

@Data
@Builder
@Embeddable
@NoArgsConstructor
@AllArgsConstructor
@SuppressWarnings("serial")
public class ViolImageComposite implements Serializable {

    private Integer plazaId;					//PLAZA_ID NUMBER (10)
    private Long laneId;						//LANE_ID NUMBER (10)
    private Date txDate;						//TX_DATE TIMESTAMP (3)
    private Long txSeqNumber;				//TX_SEQ_NUMBER NUMBER (10)
}