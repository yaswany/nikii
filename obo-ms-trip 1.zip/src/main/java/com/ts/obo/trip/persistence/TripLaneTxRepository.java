package com.ts.obo.trip.persistence;

import com.ts.obo.trip.model.TripLaneTx;
import com.ts.obo.trip.model.dto.*;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.Date;
import java.util.List;

@NoRepositoryBean
public interface TripLaneTxRepository extends ITransportationRepository<TripLaneTx, Integer> {

    /**
     * Gets message id.
     *
     * @return the message id
     */
    @Query(nativeQuery = true)
    Long getMessageId();

    /**
     * Gets lane tx id.
     *
     * @return the lane tx id
     */
    @Query(nativeQuery = true)
    Long getLaneTxId();

    @Query
    TripMessageUpdateDate findMessageAndUpdateDate(long maxHostValue, Date updateTimestamp,
                                                   int plazaId, int agencyId);
    @Query(nativeQuery = true)
    ViolationImageInfo getViolationImageCount(Date currentTripDate, List<Integer> plazaId);

    @Query(nativeQuery = true)
    ETCCavImageInfo getETCCavImageCount(Date currentTripDate, List<Integer> cavEnabledPlazaId);

    @Query(nativeQuery = true)
    ETCVpdsImageInfo getETCVpdsImageCount(Date currentTripDate, List<Integer> vpdsEnabledPlazaId);


}
