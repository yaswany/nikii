package com.ts.obo.trip.controller;

import com.ts.obo.trip.persistence.ViolImageTxRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@Slf4j
@RestController
@RequestMapping("/api/obo/trip")
public class LprVioImageController {

    @Autowired(required = true)
    private ViolImageTxRepository violImageTxRepo;

    @PutMapping("/ocrinfo/{ocrConf}/{laneTxId}")
    public void updateOCRInfo(@PathVariable("ocrConf") int ocrConf, @PathVariable("laneTxId") Long laneTxId){
        log.info("In LprVioImageController---------------ocrPlateNumber {}:: laneTxId {} ", ocrConf, laneTxId);
        violImageTxRepo.updateOCRInfo(ocrConf,laneTxId);

    }

    @PutMapping("/manualreviewinfo/{processFlag}/{laneTxId}")
    public void updateManualReviewInfo(@PathVariable("processFlag") String processFlag, @PathVariable("laneTxId") Long laneTxId){
        log.info("In LprVioImageController.updateManualReviewInfo() ::processFlag {} laneTxId {}", processFlag, laneTxId);
        violImageTxRepo.updateManualReviewInfo(processFlag,laneTxId);
    }

    @PutMapping("/updatetripconstructioninfo/{processFlag}/{laneTxId}")
    public void updateTripConstructionInfo(@PathVariable("processFlag") String processFlag, @PathVariable("laneTxId") Long laneTxId){
        log.info("In LprVioImageController.updateTripConstructionInfo() processFlag {} laneTxId {}:: ", processFlag, laneTxId);
        violImageTxRepo.updateTripConstructionInfo(processFlag,laneTxId);
    }

    @PutMapping("/updatevpdsinfoodffile/{frontOccupancy}/{frontConfidence}/{sideOccupancy}/{sideConfidence}/{laneTxId}")
    public void updateVPDSInfoODFFile(@PathVariable("frontOccupancy") int frontOccupancy,@PathVariable("frontConfidence")int frontConfidence,@PathVariable("sideOccupancy")int sideOccupancy,@PathVariable("sideConfidence")int sideConfidence,@PathVariable("laneTxId")Long laneTxId){
        log.info("In LprVioImageController.updateVPDSInfoODFFile() :: laneTxId {}", laneTxId);
        violImageTxRepo.updateVPDSInfoODFFile(frontOccupancy,frontConfidence,sideOccupancy,sideConfidence,laneTxId);
    }

}
