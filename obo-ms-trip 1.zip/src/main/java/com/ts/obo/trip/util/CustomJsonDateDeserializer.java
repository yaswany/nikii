package com.ts.obo.trip.util;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@Slf4j
public class CustomJsonDateDeserializer extends JsonDeserializer<Long> {

    @Override
    public Long deserialize(JsonParser jsonParser, DeserializationContext deserializationContext)
            throws IOException, JacksonException {
        log.info("MessageParser-UTIL : CustomJsonDateDeserializer : deserialize...!!!");
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
        String date = jsonParser.getText();
        try {
            if(date.contains("-")){
                return format.parse(date).getTime();
            } else {
                return Long.valueOf(date);
            }
        } catch (ParseException e) {
            log.error("Exception : {}",e.getMessage());
            throw new RuntimeException(e);
        }
    }

}

