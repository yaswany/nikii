package com.ts.obo.trip.client;

import com.ts.obo.trip.model.dto.LaneInfo;
import com.ts.obo.trip.model.dto.PlazaInfo;
import com.ts.obo.trip.model.dto.PlazaInfoListDTO;
import com.ts.obo.trip.util.JsonMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Slf4j
@Component
public class AppClient {

    /**
     * The Base url.
     */
    @Value("${rest.endpoint.laneUrl}")
    String laneUrl;

    /**
     * Get all plaza
     * @return list of plaza info
     */
     public List<PlazaInfo> getPlazas(){
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<String>(headers);

        ResponseEntity<PlazaInfo[]> plazaDetails=
                getRestTemplate().exchange(laneUrl, HttpMethod.GET, entity,
                        PlazaInfo[].class);
        log.info("getPlazas: {}",(new ArrayList(List.of(plazaDetails.getBody()))).size());
        return new ArrayList(List.of(plazaDetails.getBody()));
    }

    /**
     * Get all lane
     * @return list of lane info
     */
   public List<LaneInfo> getLanes(){
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        log.info("Connecting to URL: {}",laneUrl);
        ResponseEntity<LaneInfo[]> laneDetails=
                getRestTemplate().exchange(laneUrl+"lane", HttpMethod.GET, entity,
                        LaneInfo[].class);
        log.info("getLanes: {}",(new ArrayList(List.of(laneDetails.getBody()))).size());
        return new ArrayList(List.of(laneDetails.getBody()));
    }

    /**
     * Get rest template rest template.
     *
     * @return the rest template
     */
    public RestTemplate getRestTemplate(){
        return new RestTemplate();
    }

}