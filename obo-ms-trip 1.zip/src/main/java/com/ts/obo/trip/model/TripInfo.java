package com.ts.obo.trip.model;

import lombok.Data;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@Component
@Table(name = "t_trip_info")
@IdClass(TripInfoComposite.class)
public class TripInfo implements Serializable {

    @Id
    String plazaGroup;  //primaryKey
    @Id
    String direction;   //primaryKey
    @Id
    long messageId;     //primaryKey
    @Id
    int plazaId;        //primaryKey
    @Id
    int laneId;         //primaryKey

    String bufferedFlag;
    long tripId;
    long laneTxId;
    String acctNo;
    String status;
    Date createTmsp;
    Date matchTmsp;
    String deviceNo;
    String plateNumber;
    String plateState;
    int etcAccountId;
    float fullFare;
    float fareWithGrace;
    float fareWithoutGrace;
    Date txTimeApplied;
    String graceTimeApplied;
    String fareTypeApplied;
    String tripInCode;
    long tollSchId;
    float tollMileage;
    long segmentId;
    long tollRateId;
    long disTollRateId;
    int occupancy;
    int agencyId;
    int cavFlag;
    String sendToBosFlag;
    String auditStatusFlag;
    int incidentFilterId;
    Date txDate;
    int txnProcStatus;
    int cTagStats;
    int tagPosition;
    int digitalPosition;
    int finalPosition;
    int vpdsPosition;
    float vpdsConfidence;
    int reviewStatus;
    int updatedBy;
    Date updatedTs;
    @Column(name="device2_no")
    String device2No;
    float segmentFullFare;
    float segmentMinFare;
    float segmentFallbackFare;
    int fltReviewStatus;
    int fltReviewEmpId;
    Date fltReviewDate;
    int fliterId;
    String tripAdjustStatus;
    long adjustedLaneTxId;
    int nonRevFlag;
    int	tripCompPosition;
    float sovFare;
    @Column(name="hov2_fare")
    float hov2Fare;
    @Column(name="hov3_fare")
    float hov3Fare;
    @Column(name="device1_protocol")
    int device1Protocol;
    @Column(name="device2_protocol")
    int device2Protocol;
    int adjustedReason;
}
