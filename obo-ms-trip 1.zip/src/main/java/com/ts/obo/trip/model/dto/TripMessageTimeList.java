package com.ts.obo.trip.model.dto;

import java.util.Date;

public interface TripMessageTimeList {

    long getMaxHostValue();
    Date getUpdateTimestamp();
    int getPlazaId();
}
