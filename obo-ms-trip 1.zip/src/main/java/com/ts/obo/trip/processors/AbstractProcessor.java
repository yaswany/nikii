package com.ts.obo.trip.processors;

import com.ts.obo.trip.client.AppClient;
import com.ts.obo.trip.model.kafka.LaneMessage;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class AbstractProcessor {
    @Autowired
    AppClient appClient;

    abstract void process(LaneMessage laneMessage);
}

