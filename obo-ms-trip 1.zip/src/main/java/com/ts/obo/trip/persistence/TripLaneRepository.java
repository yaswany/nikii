package com.ts.obo.trip.persistence;

import com.ts.obo.trip.model.TripLane;

import com.ts.obo.trip.model.dto.PlazaLaneInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.query.Param;

@NoRepositoryBean
public interface TripLaneRepository extends ITransportationRepository<TripLane, Integer> {

    @Query
    public PlazaLaneInfo getInfo(@Param("externPlazaId") String externPlazaId, @Param("externLaneId") String externLaneId);

}