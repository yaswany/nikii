package com.ts.obo.trip.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "t_trip_mileage")
public class TripMileage implements Serializable {

    @Id
    private Integer agencyId;
    private Integer begTz;
    private Integer endTz;
    private Integer segId;
    private Integer chargedDistance;

}
