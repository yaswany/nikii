package com.ts.obo.trip.util;

import org.springframework.stereotype.Component;

@Component
public class Incrementor {

    /**
     * Checks the value, increment and return
     * @param value
     * @return
     */
    public Long increment(Long value){
        if(value == null || value == 0){
            return  1L;
        } else {
            return  value+1;
        }
    }
}

