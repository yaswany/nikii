package com.ts.obo.trip.persistence.sql;

import com.ts.obo.trip.model.ViolImageTx;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Qualifier("ViolImageTxRepository")
@Repository
public interface ViolImageTxSqlRepository extends JpaRepository<ViolImageTx, Long> {
}