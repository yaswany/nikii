package com.ts.obo.trip.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "t_trip_plaza")
public class TripPlaza implements Serializable {

    private static final long serialVersionUID = 2612578813518671670L;

    @Id
    private Long plazaId;                           //PLAZA_ID	BIGINT PRIMARY KEY,
    private String externPlazaId;                   //EXTERN_PLAZA_ID	VARCHAR(255),
    private String name;                            //NAME	VARCHAR(255),
    private Integer addressId;                      //ADDRESS_ID	INT,
	@DateTimeFormat(pattern = "yyyy-MM-dd hh:mm:ss")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private Date openedDt;                          //OPENED_DT	DATE,
    private Integer plazaMask;                      //PLAZA_MASK	INT,
	@DateTimeFormat(pattern = "yyyy-MM-dd hh:mm:ss")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTs;                          //UPDATE_TS	TIMESTAMP(2),
    private Integer agencyId;                       //AGENCY_ID	INT,
    private Integer defaultPlanId;                  //DEFAULT_PLAN_ID	INT,
    private String revenueTime;                     //REVENUE_TIME	VARCHAR(255),
    private String courtId;                         //COURT_ID	VARCHAR(255),
    private Integer plazaGroup;                     //PLAZA_GROUP	INT,
    private String ipAddress;                       //IP_ADDRESS	VARCHAR(255),
    private String nodename;                        //NODENAME	VARCHAR(255),
    private String username;                        //USERNAME	VARCHAR(255),
    private String password;                        //PASSWORD	VARCHAR(255),
    private String tsDir;                           //TS_DIR	VARCHAR(255),
    private String txDir;                           //TX_DIR	VARCHAR(255),
    private String imageIncomingVolume;             //IMAGE_INCOMING_VOLUME	VARCHAR(255),
    private String imageArchiveVolume;              //IMAGE_ARCHIVE_VOLUME	VARCHAR(255),
    private String plazaTypeInd;                    //PLAZA_TYPE_IND	VARCHAR(255),
    private String endPlazaInd;                     //END_PLAZA_IND	VARCHAR(255),
    private String sectionCodeInd;                  //SECTION_CODE_IND	VARCHAR(255),
    private Integer sectionId;                      //SECTION_ID	INT,
    private String plazaAbbr;                       //PLAZA_ABBR	VARCHAR(255),
    private Integer plazaSeqNumber;                 //PLAZA_SEQ_NUMBER	INT,
    private Double mileage;                         //MILEAGE	DECIMAL,
    private Double hwyNo;                           //HWY_NO	DECIMAL,
    private String isHomePlaza;                     //IS_HOME_PLAZA	VARCHAR(255),
    private Integer portNo;                         //PORT_NO	INT,
    private String graceTime;                       //GRACE_TIME	VARCHAR(255),
    private String isDynamicDmsDelay;               //IS_DYNAMIC_DMS_DELAY	VARCHAR(255),
    private String maxGraceTime;                    //MAX_GRACE_TIME	VARCHAR(255),
    private String lprEnabled;                      //LPR_ENABLED	VARCHAR(255),
    private Double depositVariance;                 //DEPOSIT_VARIANCE	DECIMAL,
    private Double noFundsAdminFee;                 //NO_FUNDS_ADMIN_FEE	DECIMAL,
    private Integer speedTreshold;                  //SPEED_TRESHOLD	INT,
    private String isLegacy;                        //IS_LEGACY	VARCHAR(255),
    private String vpdsEnabled;                     //VPDS_ENABLED	VARCHAR(255),
    private String locLongitude;                    //LOC_LONGITUDE	VARCHAR(255),
    private String locLatitude;                     //LOC_LATITUDE	VARCHAR(255),
    private String cavEnabled;                      //CAV_ENABLED	VARCHAR(255)

}
