package com.ts.obo.trip.persistence.sql;

import com.ts.obo.trip.model.TripTx;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Qualifier("TripTxRepository")
@Repository
public interface TripTxSqlRepository extends JpaRepository<TripTx, Long> {
}