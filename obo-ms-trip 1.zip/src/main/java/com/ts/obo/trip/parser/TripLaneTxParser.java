package com.ts.obo.trip.parser;

import com.ts.obo.trip.model.TripLaneTx;
import com.ts.obo.trip.model.dto.PlazaInfo;
import com.ts.obo.trip.model.dto.PlazaLaneInfo;
import com.ts.obo.trip.model.kafka.LaneMessage;
import com.ts.obo.trip.model.kafka.TollTransaction;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class TripLaneTxParser extends AbstractParser{

    /**
     * Construct message header message header.
     *
     * @param laneMessage the header
     * @return the message header
     */
    public TripLaneTx constructMessageHeader(LaneMessage laneMessage){

        PlazaLaneInfo plazaInfo=getPlazaLaneInfo(laneMessage);
        TollTransaction tollTransaction = laneMessage.getTollTransaction();
        TripLaneTx tripLaneTx = new TripLaneTx();

        tripLaneTx.setMessageId(0L);
        tripLaneTx.setPlazaId(plazaInfo.getPlazaId().intValue());
        tripLaneTx.setTxDate(laneMessage.getTxnTime() == null ? new Date() : new Date(laneMessage.getTxnTime()));
        tripLaneTx.setTollTxType(laneMessage.getRecordType() == null ? 0 : laneMessage.getRecordType());
        tripLaneTx.setLaneId(plazaInfo.getLaneId().intValue());
        tripLaneTx.setTollTxSubType(laneMessage.getRecordSubType() == null ? 0 : laneMessage.getRecordSubType());
        tripLaneTx.setTollRevenueType(10);
        tripLaneTx.setLaneTxId(0L);
        tripLaneTx.setDeviceProgramStatus(0);
        tripLaneTx.setLaneId(plazaInfo.getLaneId().intValue());
        tripLaneTx.setVehSeqNo(tollTransaction.getVehicleSequenceNo() == null ? 0 : Integer.valueOf(tollTransaction.getVehicleSequenceNo()));

        return tripLaneTx;
    }
}
