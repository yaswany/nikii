package com.ts.obo.trip.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;

@Slf4j
@ControllerAdvice
public class OBORestResponseExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(Throwable.class)
    public  ResponseEntity<Object> handleException(Exception ex)  {
        OBORestErrorResponse restErrorResponse = new OBORestErrorResponse();
        restErrorResponse.setTimestamp(LocalDateTime.now());
        restErrorResponse.setMessage(ex.getMessage());
        restErrorResponse.setType(getType(ex).name());
        restErrorResponse.setStatus(getStatus(ex));

        log.error("OBOException :", ex);
        return new ResponseEntity(restErrorResponse,getStatus(ex));
    }

    private ErrorType  getType(Exception ex){
        if(ex instanceof OBOException){
            OBOException oex = (OBOException) ex;
            return  oex.getErrorType();
        }
        return ErrorType.InternalError;
    }

    private HttpStatus getStatus(Exception ex){
        if(ex instanceof OBOException){
            OBOException oex = (OBOException) ex;
            if(oex.getErrorType() == ErrorType.ValidationError){
                return HttpStatus.BAD_REQUEST;
            }else if(oex.getErrorType() == ErrorType.NoDataError){
                return HttpStatus.NO_CONTENT;
            }
        }

        return HttpStatus.INTERNAL_SERVER_ERROR;
    }
}