package com.ts.obo.trip.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ts.obo.trip.model.kafka.LaneMessage;
import com.ts.obo.trip.processors.TripInfoProcessor;
import com.ts.obo.trip.processors.TripLaneTxProcessor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * The type Message service.
 */
@Slf4j
@Service
public class MessageService {

    @Autowired
    private TripLaneTxProcessor tripLaneProcessor;

    @Autowired
    private TripInfoProcessor tripInfoProcessor;

    /**
     * Process message.
     *
     * @param queueMessage the queue message
     */
    public void processMessage(String queueMessage) {
        try {
            log.info("queueMessage>>>AAA>> "+queueMessage);
            ObjectMapper om = new ObjectMapper();
            // configure ignore unknown properties
            om.configure(DeserializationFeature
                            .FAIL_ON_UNKNOWN_PROPERTIES,
                    false);
                if(queueMessage.contains("TollTransaction")){  // means 10,16,12 transaction

                    LaneMessage laneMessage
                            = om.readValue(queueMessage, LaneMessage.class);
                    log.info("Toll Transaction>>>BBB>> "+laneMessage);

                    //LaneMessage laneMessage = JsonMapper.toObject(queueMessage, LaneMessage.class);
                    tripLaneProcessor.process(laneMessage);
                    tripInfoProcessor.process(laneMessage);
                    log.info("Toll Transaction Message Saved Successfully...!!!\n\n");
                }
            } catch (Exception e){
            log.error("Error while processing message : {}",e.getMessage());
      }
    }
}
