package com.ts.obo.trip.model.dto;

import java.util.Date;

public interface TripMessageUpdateDate {

    long getMessageId();
    Date getTxDate();
}
