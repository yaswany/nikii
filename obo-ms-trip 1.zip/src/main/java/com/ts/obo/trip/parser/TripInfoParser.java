package com.ts.obo.trip.parser;

import com.ts.obo.trip.model.TripInfo;
import com.ts.obo.trip.model.TripLane;
import com.ts.obo.trip.model.dto.PlazaInfo;
import com.ts.obo.trip.model.dto.PlazaLaneInfo;
import com.ts.obo.trip.model.kafka.LaneMessage;
import com.ts.obo.trip.model.kafka.TollTransaction;
import com.ts.obo.trip.persistence.TripLaneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TripInfoParser extends AbstractParser{


    public TripInfo constructMessageHeader(LaneMessage laneMessage){

        PlazaLaneInfo plazaInfo=getPlazaLaneInfo(laneMessage);
        TollTransaction tollTransaction = laneMessage.getTollTransaction();
        TripInfo tripInfo = new TripInfo();

        tripInfo.setPlazaId(plazaInfo.getPlazaId().intValue());
        tripInfo.setLaneId(plazaInfo.getLaneId().intValue());
        tripInfo.setDeviceNo(getDeviceNumber(tollTransaction));
        tripInfo.setDirection("W");
        // tripInfo.setBufferedFlag(tollTransaction.getR);
        //tripInfo.setAgencyId(plazaInfo.getAgencyId());
        tripInfo.setAgencyId(83);
//        tripInfo.setTagPosition(tollTransaction.getTagSwitchPosition() == null ? 0 : Integer.valueOf(tollTransaction.getTagSwitchPosition()));
//        tripInfo.setDigitalPosition(tollTransaction.getDigitalSwitchPosition() == null ? 0 : Integer.valueOf(tollTransaction.getDigitalSwitchPosition()));
//        tripInfo.setFinalPosition(tollTransaction.getFinalSwitchPosition() == null ? 0 : Integer.valueOf(tollTransaction.getFinalSwitchPosition()));
        tripInfo.setDevice2No("");
        tripInfo.setDevice1Protocol(tollTransaction.getDeviceEncodedRev() == null ? 0 : Integer.valueOf(tollTransaction.getDeviceEncodedRev()));
        tripInfo.setDevice2Protocol(tollTransaction.getDeviceEncodedRev2() == null ? 0 : Integer.valueOf(tollTransaction.getDeviceEncodedRev2()));
        //tripInfo.setTxDate();

        return tripInfo;
    }

    private String getDeviceNumber(TollTransaction tollTransaction){

        String deviceNumber = tollTransaction.getTagInstitution();
        if (tollTransaction.getTagNumber().length() > 7) {
            deviceNumber = deviceNumber+ tollTransaction.getTagNumber().substring(0, 7);
        } else {
            deviceNumber = deviceNumber+ tollTransaction.getTagNumber();
        }
        return deviceNumber;
    }

}
