package com.ts.obo.trip.model;

import lombok.Data;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@Component
@Table(name = "t_trip_tx")
public class TripTx implements Serializable {

    @Id
    long tripSerialNo; //primary_key
    long tripId;
    int entryPlazaId;
    int entryLaneId;
    Date entryTxDate;
    long collectorId;
    int tourSegmentId;
    int exitPlazaId;
    int exitLaneId;
    Date exitTxDate;
    String deviceNo;
    String accountNo;
    String entryDstFlag;
    int tollRevenueType;
    int tripAvcClass;
    int tagClass;
    int tagIagClass;
    int tripAxles;
    int tagAxles;
    int actualAxles;
    int laneMode;
    int laneState;
    String laneHealth;
    int deviceReadCount;
    int deviceWritePerf;
    int tagStatus;
    String plateNumber;
    String plateState;
    int ocrConf;
    String imageTaken;
    int entryVehicleSpeed;
    String bufferedFlag;
    float tripFareAmount;
    Date tourDate;
    String tripStatus;
    long tollScheduleId;
    String tripAdjustStatus;
    long adjustedTripId;
    Date createTmsp;
    Date updateTmsp;
    String graceTime;
    String exitDstFlag;
    int exitVehicleSpeed;
    String fareType;

    int plazaGroup;
    String direction;
    String isMisclass;
    int tollTxType;
    int txSeqNo;
    int actualExtraAxles;
    int accountAgencyId;
    int tripClass;
    float tripFullfare;
    int reviewedClass;
    int segCount;
    String txnType;
    String txnSubType;
    String tollSystemType;
    long entryLaneSerial;
    long exitLaneSerial;
    int deviceProgramStatus;
    int speedViolation;
    String reciprocityTxn;
    String debitCreditInd;
    int externalFileId;
    String entryExPlazaId;
    String exitExPlazaId;
    String entryExLaneId;
    String exitExLaneId;
    String laneDataSource;
    String buffer;
    String carPoolFlag;
    String isAvcOverheight;
    long trcsFileId;
    int tollTxSubType;
    int agencyId;
    int fareComputedMode;
    int tripSpeed;
    int etcAccountId;
    long tollRateId;
    long disTollRateId;
    int occupancy;
    int extraTrgrace;
    float tripDistance;
    float tripTravelTime;
    long linkedTripId;
    int cavFlag;
    String auditStatusFlag;
    String incidentFilter;
    int tagPosition;
    int digitalPosition;
    int laneFinalPosition;
    int tripCompPosition;
    int vpdsPosition;
    String sendToBosFlag;
    int reviewStatus;
    int reviewEmpId;
    Date reviewDate;
    int updatedBy;
    float tripMinFare;
    float tripFallbackFare;
    int filterId;
    float sovFare;
    @Column(name="hov2_fare")
    float hov2Fare;
    @Column(name="hov3_fare")
    float hov3Fare;
    int nonRevFlag;
    String occModeSource;
    int adjEmpId;
    String isOdsViol;
    int plateType;
    @Column(name="device2_no")
    String device2No;
    @Column(name="tag2_status")
    int tag2Status;
    @Column(name="device2_program_status")
    int device2ProgramStatus;
    int tagProtocol;
    int entryLaneMode;
    String exceptionCode;
    int exitLaneMode;
    int imageCount;
    int ocrConfState;
    String bestImageFileName;
    long bestImageTxnId;
    String tagFileDatetime;
    String tagFileIncrementDatetime;
    @Column(name="tag2_protocol")
    int tag2Protocol;
    int preclassClass;
    int postclassClass;
    int collectorClass;
    long entryLaneSeqNo;
    long exitLaneSeqNo;
    int origEntryPlazaId;
    int tollSummaryId;
}
