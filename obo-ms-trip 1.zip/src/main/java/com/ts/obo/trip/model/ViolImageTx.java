package com.ts.obo.trip.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "t_viol_image_tx")
@IdClass(ViolImageComposite.class)
public class ViolImageTx implements Serializable {

    @Id
    private Long laneId;
    @Id
    private Long laneTxId;
    @Id
    private Long txSeqNumber;
    @Id
    private Integer plazaId;
    @Id
    private Date txDate;

    private Long messageId;

    private String inFileName;

    private String outFileName;

    private String processFlag;

    private Date receiveDate;

    private Date processDate;

    private Integer ocrConf;

    private String plateNumber;

    private String plateState;

    private String vehSeqNumber;

    private Date ftpDate;

    private Integer laneImgCnt;

    private Integer procImgCnt;

    private Date updateTs;

    private Integer axleCount;

    private Integer imageStatus;

    private String imageTakenReason;

    private Integer retFileId;

    private Integer trFileId;

    private String cscLookupKey;

    private Integer imgType;

    private Long imageTxId;

    private Integer imageSelected;

    private Date imageReviewTimestamp;

    private Long reviewedVehicleType;

    private Long imageRvwClerkId;

    private Long postclassAxles;

    private Integer procImageCnt;

    private String ocrPlateNumber;

    private String ocrPlateState;

    private Date reviewedDate;

    private Date txTimeStamp;

    private String zipFileName;

    private String reducedPlate;

    private Integer readAviClass;

    private String processDesc;

    private Integer ocrThreshold;

    private Integer ocrStatus;

    private String ocrPlateCountry;

    private Date ocrEndTimestamp;

    private String matchType;

    private Integer manualPlateType;

    private String manualPlateState;

    private String manualPlateNumber;

    private String manualPlateCountry;

    private Long imageBatchSeqNumber;

    private Long imageBatchId;

    private Long fpThreshold;

    private Long fpStatus;

    private Long fpConf;

    private Long dmvPlateType;

    private String deviceNo;

    private String colorBw;

    private Long actualClass;

    private Long actualAxles;

    private Long reviewedClass;

    private Long ocrRunMode;

    private Date ocrStartTimestamp;

    private Integer iagClass;

    private String isImageAvail;

    private Integer tagPosition;

    private Integer digitalPosition;

    private Integer finalPosition;

    private Integer vpdsPosition;

    private Integer vpdsConfidence;

    private String sendToBosFlag;

    private String isOdsImageAvail;

    private Integer alprRoiCount;

    private String ortFlag;

    private Integer vpdsManFntPos;

    private Integer vpdsManFntCnf;

    private Integer vpdsManSidePos;

    private Integer vpdsManSideCnf;

    private String vpdsManFntRoi;

    private String vpdsManSideRoi;

    private Integer vsrConfidence;

    private String vsrPlateState;

    private String vsrPlateNumber;

    private String vsrPlateCountry;

    private String imgFileIndex;

    private String odsInFileName;

    private Long totalVpdsOccupancy;

    private String plateCountry;

    private Long vpdsStatus;

    private Date orgImgTimestamp;

    private String reviewedImageNumber;

    private Integer odsRoiCount;

    private Date unzipProcessDate;

    private String isUnredactedImageAvail;

    private String unredactedInFileName;

    private Integer vpdsFntPos;

    private Integer vpdsFntCnf;

    private Integer vpdsSidePos;

    private Integer vpdsSideCnf;

    private Integer cavFlag;
    private Integer plateType;
    private String ocrImageTimestamp;
    private Integer ocrStateConf;
}
