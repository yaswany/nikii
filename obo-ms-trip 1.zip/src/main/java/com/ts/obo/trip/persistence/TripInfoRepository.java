package com.ts.obo.trip.persistence;

import com.ts.obo.trip.model.TripInfo;
import com.ts.obo.trip.model.TripLaneTx;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface TripInfoRepository extends ITransportationRepository<TripInfo, String> {

}