package com.ts.obo.trip.model;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "t_trip_summary")
public class TripSummary implements Serializable {

    @Id
    private Integer tollSummaryId;
    private Integer tourSegmentId;
    private Integer vehicleClass;
    private Integer tollRevenueType;
    private Integer planType;
    private Integer auditId;
    private Integer agencyId;
    private Integer plazaId;
    private Integer laneId;
    private Integer vehicleCount;
    private Integer actualAxles;
    private Integer aviAxles;
    private Integer collectorAxles;
    private Integer preclassAxles;
    private Integer postclassAxles;
    private float fullFareAmount;
    private float discountedAmount;
    private float collectedAmount;
    private float unrealizedAmount;
    private Integer tranCode;
    private Integer orgTollSummeryId;
    private String isAviSummarized;
    private Date updatesTs;
    private String summeryType;
    private Integer dailySummeryId;
    private Integer tollTxType;
    private Integer laneMode;
    private Integer collectorId;
    private Integer etcTxStatus;
    private Integer misclassCount;
    private Date transactionDate;
    private Date postedDate;
    private Date reconDate;
    private String fileTypeId;
    private Integer externFileId;
    private String laneTxTypeInd;
    private String laneTxSubtypeInd;
    private String tollSystemTypeInd;
    private Integer atpFileId;
    private Integer accountAgencyId;
    private String hostXferFlag;
    private float avcClassAmount;
    private float collectorClassAmount;
    private Date tourDate;
    private Integer laneState;
    private Integer entryPlazaId;
    private Integer entryLaneId;
    private Integer segmentCode;
    private String exceptionCode;
    private Integer tripHour;
    private Integer travelDistance;

}
