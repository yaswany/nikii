package com.ts.obo.trip.persistence;

import com.ts.obo.trip.model.ViolImageTx;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.transaction.annotation.Transactional;

@NoRepositoryBean
public interface ViolImageTxRepository extends ITransportationRepository<ViolImageTx, Long> {


    /**
     * @param ocrConf
     * @param laneTxId
     */
    @Modifying
    @Transactional
    @Query
    void updateOCRInfo(int ocrConf, Long laneTxId);

    /**
     * @param processFlag
     * @param laneTxId
     */
    @Modifying
    @Transactional
    @Query
    void updateManualReviewInfo(String processFlag, Long laneTxId);

    /**
     * @param frontOccupancy
     * @param frontConfidence
     * @param sideOccupancy
     * @param sideConfidence
     */
    @Modifying
    @Transactional
    @Query
    void updateVPDSInfoODFFile(int frontOccupancy,int frontConfidence,int sideOccupancy,int sideConfidence,Long laneTxId);

    /**
     * @param FpMatch
     * @param laneTxId
     */
    @Modifying
    @Transactional
    @Query
    void updateTripConstructionInfo(String FpMatch, Long laneTxId);

    /**
     *
     * @param laneTxId
     * @return
     */
    ViolImageTx findByLaneTxId(Long laneTxId);

}