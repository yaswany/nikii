package com.ts.obo.trip.service;

import com.ts.obo.trip.client.AppClient;
import com.ts.obo.trip.model.TripPlaza;
import com.ts.obo.trip.model.dto.LaneInfo;
import com.ts.obo.trip.model.dto.PlazaInfoListDTO;
import com.ts.obo.trip.model.dto.TripMessageTimeList;
import com.ts.obo.trip.parser.TripLaneParser;
import com.ts.obo.trip.parser.TripPlazaParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * The  Pre trip starter class used to start the pre-trip process.
 */
@Service
public class PreTripStarter {

    @Autowired
    PreTripService preTripService;

    @Autowired
    AppClient appClient;

    @Autowired
    TripLaneParser tripLaneParser;

    @Autowired
    TripPlazaParser tripPlazaParser;

    /**
     * Start pre trip process.
     */
    public void startPreTripProcess(){

        /** Get all t_plaza and t_lane records */
        tripLaneParser.constructMessageHeader(appClient.getLanes());
        tripPlazaParser.constructMessageHeader(appClient.getPlazas());

        /**Start pre-trip validation */
        preTripService.preTripProcess();
    }

}
