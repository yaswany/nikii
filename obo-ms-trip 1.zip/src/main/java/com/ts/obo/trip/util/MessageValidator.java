package com.ts.obo.trip.util;

import lombok.extern.slf4j.Slf4j;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * The type Message validator.
 */
@Slf4j
public class MessageValidator {

    /**
     * The constant DATE_AND_TIME_TILL_MILLISECONDS.
     */
    public static final String DATE_AND_TIME_TILL_MILLISECONDS = "yyyy-MM-dd HH:mm:ss:SSS";
    /**
     * The constant DATE_AND_TIME_TILL_SECONDS.
     */
    public static final String DATE_AND_TIME_TILL_SECONDS = "yyyy-MM-dd HH:mm:ss";
    private final static String INVALID_DATE_ERROR = "Invalid String to be parsed as date. Might be it is not in the format yyyyMMddHHmmssSS. Value provided is : ";
    private static final String UTC_TIMEZONE = "Etc/UTC";
    private static final String EMPTY_STRING = "";

    /**
     * Validate null int.
     *
     * @param intValue the int value
     * @return the int
     */
    public final static int validateNull(Integer intValue) {
        if(intValue == null) {
            return 0;
        }else {
            return intValue.intValue();
        }
    }

    /**
     * Validate null long.
     *
     * @param longValue the long value
     * @return the long
     */
    public final static long validateNull(Long longValue) {
        if(longValue == null) {
            return 0;
        }else {
            return longValue.longValue();
        }
    }

    /**
     * Validate null string.
     *
     * @param value the value
     * @return the string
     */
    public final static String validateNull(String value) {
        if(value == null) {
            return EMPTY_STRING;
        }else {
            return value;
        }
    }

    /**
     * Format to date string.
     *
     * @param dateString the date string
     * @return the string
     */
    public String formatToDate(String dateString){
        String dateAndTimeTillSeconds = "0000-00-00 01:00:00";
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(DATE_AND_TIME_TILL_MILLISECONDS);
            Date date = sdf.parse(getFormate(dateString));
            log.info("DATE_AND_TIME_TILL_MILLISECONDS : {}",date);

            SimpleDateFormat format1 = new SimpleDateFormat(DATE_AND_TIME_TILL_SECONDS);
            dateAndTimeTillSeconds = format1.format(date);
            log.info("DATE_AND_TIME_TILL_SECONDS : {}",dateAndTimeTillSeconds);
        } catch (Exception e){
            log.error("Error : {}",e.getMessage(),e);
        }
        return dateAndTimeTillSeconds;
    }

    private String getFormate(String dateStr){
        String dateAndTimeTillMilliSeconds = "";
        for(int i=0; i<dateStr.length(); i++) {
            dateAndTimeTillMilliSeconds += dateStr.charAt(i);
            if(i==3 || i==5) {
                dateAndTimeTillMilliSeconds += "-";
            } if(i==7) {
                dateAndTimeTillMilliSeconds += " ";
            } if(i==9 || i==11 || i==13) {
                dateAndTimeTillMilliSeconds += ":";
            }
        }
        log.info("===>>> : DATE_AND_TIME_TILL_MILLISECONDS : {}",dateAndTimeTillMilliSeconds);
        return dateAndTimeTillMilliSeconds;
    }
}
