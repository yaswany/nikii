package com.ts.obo.trip.model;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@Builder
@Embeddable
@NoArgsConstructor
@AllArgsConstructor
public class TripInfoComposite implements Serializable {

    String plazaGroup;  //primaryKey
    String direction;   //primaryKey
    long messageId;     //primaryKey
    int plazaId;        //primaryKey
    int laneId;         //primaryKey
}

