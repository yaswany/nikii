package com.ts.obo.trip.parser;

import com.ts.obo.trip.model.TripPlaza;
import com.ts.obo.trip.model.dto.PlazaInfo;
import com.ts.obo.trip.persistence.TripPlazaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class TripPlazaParser {

    @Autowired
    TripPlazaRepository tripPlazaRepository;

    public void constructMessageHeader(List<PlazaInfo> plazaInfo){

        TripPlaza tripPlaza = new TripPlaza();

        plazaInfo.stream().forEach(plaza -> {

            tripPlaza.setPlazaId((plaza.getPlazaId()));
            tripPlaza.setVpdsEnabled(plaza.getVpdsEnabled());

            tripPlaza.setExternPlazaId(plaza.getExternPlazaId());                   //EXTERN_PLAZA_ID	VARCHAR(255),
            tripPlaza.setName(plaza.getName());                            //NAME	VARCHAR(255),
            tripPlaza.setAddressId(plaza.getAddressId());                      //ADDRESS_ID	INT,
            tripPlaza.setOpenedDt(plaza.getOpenedDt());                          //OPENED_DT	DATE,
            tripPlaza.setPlazaMask(plaza.getPlazaMask());                      //PLAZA_MASK	INT,
            tripPlaza.setUpdateTs(plaza.getUpdateTs());                          //UPDATE_TS	TIMESTAMP(2),
            tripPlaza.setAgencyId(plaza.getAgencyId());                       //AGENCY_ID	INT,
            tripPlaza.setDefaultPlanId(plaza.getDefaultPlanId());                  //DEFAULT_PLAN_ID	INT,
            tripPlaza.setRevenueTime(plaza.getRevenueTime());                     //REVENUE_TIME	VARCHAR(255),
            tripPlaza.setCourtId(plaza.getCourtId());                         //COURT_ID	VARCHAR(255),
            tripPlaza.setPlazaGroup(plaza.getPlazaGroup());                     //PLAZA_GROUP	INT,
            tripPlaza.setIpAddress(plaza.getIpAddress());                       //IP_ADDRESS	VARCHAR(255),
            tripPlaza.setNodename(plaza.getNodename());                        //NODENAME	VARCHAR(255),
            tripPlaza.setUsername(plaza.getUsername());                        //USERNAME	VARCHAR(255),
            tripPlaza.setPassword(plaza.getPassword());                        //PASSWORD	VARCHAR(255),
            tripPlaza.setTsDir(plaza.getTsDir());                           //TS_DIR	VARCHAR(255),
            tripPlaza.setTxDir(plaza.getTxDir());                           //TX_DIR	VARCHAR(255),
            tripPlaza.setImageIncomingVolume(plaza.getImageIncomingVolume());             //IMAGE_INCOMING_VOLUME	VARCHAR(255),
            tripPlaza.setImageArchiveVolume(plaza.getImageArchiveVolume());              //IMAGE_ARCHIVE_VOLUME	VARCHAR(255),
            tripPlaza.setPlazaTypeInd(plaza.getPlazaTypeInd());                    //PLAZA_TYPE_IND	VARCHAR(255),
            tripPlaza.setEndPlazaInd(plaza.getEndPlazaInd());                     //END_PLAZA_IND	VARCHAR(255),
            tripPlaza.setSectionCodeInd(plaza.getSectionCodeInd());                  //SECTION_CODE_IND	VARCHAR(255),
            tripPlaza.setSectionId(plaza.getSectionId());                      //SECTION_ID	INT,
            tripPlaza.setPlazaAbbr(plaza.getPlazaAbbr());                       //PLAZA_ABBR	VARCHAR(255),
            tripPlaza.setPlazaSeqNumber(plaza.getPlazaSeqNumber());                 //PLAZA_SEQ_NUMBER	INT,
            tripPlaza.setMileage(plaza.getMileage());                         //MILEAGE	DECIMAL,
            tripPlaza.setHwyNo(plaza.getHwyNo());                           //HWY_NO	DECIMAL,
            tripPlaza.setIsHomePlaza(plaza.getIsHomePlaza());                     //IS_HOME_PLAZA	VARCHAR(255),
            tripPlaza.setPortNo(plaza.getPortNo());                         //PORT_NO	INT,
            tripPlaza.setGraceTime(plaza.getGraceTime());                       //GRACE_TIME	VARCHAR(255),
            tripPlaza.setIsDynamicDmsDelay(plaza.getIsDynamicDmsDelay());               //IS_DYNAMIC_DMS_DELAY	VARCHAR(255),
            tripPlaza.setMaxGraceTime(plaza.getMaxGraceTime());                    //MAX_GRACE_TIME	VARCHAR(255),
            tripPlaza.setLprEnabled(plaza.getLprEnabled());                      //LPR_ENABLED	VARCHAR(255),
            tripPlaza.setDepositVariance(plaza.getDepositVariance());                 //DEPOSIT_VARIANCE	DECIMAL,
            tripPlaza.setNoFundsAdminFee(plaza.getNoFundsAdminFee());                 //NO_FUNDS_ADMIN_FEE	DECIMAL,
            tripPlaza.setSpeedTreshold(plaza.getSpeedTreshold());                  //SPEED_TRESHOLD	INT,
            tripPlaza.setIsLegacy(plaza.getIsLegacy());                        //IS_LEGACY	VARCHAR(255),
            tripPlaza.setLocLongitude(plaza.getLocLongitude());                    //LOC_LONGITUDE	VARCHAR(255),
            tripPlaza.setLocLatitude(plaza.getLocLatitude());                     //LOC_LATITUDE	VARCHAR(255),
            tripPlaza.setCavEnabled(plaza.getCavEnabled());                      //CAV_ENABLED	VARCHAR(255)

            tripPlazaRepository.save(tripPlaza);
        });
    }
}
