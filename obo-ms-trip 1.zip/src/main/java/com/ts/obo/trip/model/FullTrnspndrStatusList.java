package com.ts.obo.trip.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "t_full_trnspndr_statuslist")
public class FullTrnspndrStatusList implements Serializable {

    private String tagProtocal;
    private String tagNumber;
    @Id
    private String accountId;
    private String tagStatus;
    private String declaredTagMode;
    private Date modeEffDateTime;
    private String tagNonrev;
    private String tagCav;
    private String tagSwitchableHov;
    private String addIncremental;
    private String accountStatus;
    private String fileName;
    private String processFlag;
    private Date updatedTs;
    private String extTagNumber;
    private String isDeleted;
    private String tagAgencyId;

}
