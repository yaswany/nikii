package com.ts.obo.trip.persistence.nosql;

import com.ts.obo.trip.model.PlazaGetInfo;
import com.ts.obo.trip.persistence.PlazaGetInfoRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Qualifier("PlazaGetInfoRepository")
@Repository
public interface PlazaGetInfoNoSqlRepository extends CrudRepository<PlazaGetInfo, Integer>, PlazaGetInfoRepository {
}