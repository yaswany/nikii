package com.ts.obo.trip.controller;

import com.ts.obo.trip.model.ViolImageTx;
import com.ts.obo.trip.persistence.ViolImageTxRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/obo/trip")
public class UnzipViolImageController {

    @Autowired
    ViolImageTxRepository violImageTxRepo;

    @PostMapping("/saveEntity")
    public void saveEntity(@RequestBody ViolImageTx violImageTx){
        log.info("In UnzipViolImageController.saveEntity() :: ",violImageTx);
        violImageTxRepo.save(violImageTx);
    }

    @GetMapping("/findByLaneTxId/{laneTxId}")
    public ViolImageTx findByLaneTxId(@PathVariable("laneTxId") Long laneTxId){
        log.info("In UnzipViolImageController.findByLaneTxId() :: laneTxId {}",laneTxId);
        return violImageTxRepo.findByLaneTxId(laneTxId);
    }
}
