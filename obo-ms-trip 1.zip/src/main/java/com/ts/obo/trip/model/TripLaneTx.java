package com.ts.obo.trip.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Date;


@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "t_trip_lane_tx")
@IdClass(TripLaneTxComposite.class)
public class TripLaneTx implements Serializable {

    @Id
    private Long messageId;
    @Id
    private Integer plazaId;
    @Id
    private Integer laneId;
    @Id
    private Long laneTxId;
   // private Long laneMessageId;
    private Date txDate;
    private Integer tollTxType;
    private Integer tollTxSubType;
    private Integer vehSeqNo;
    private Integer deviceProgramStatus;
    private Integer tollRevenueType;
}