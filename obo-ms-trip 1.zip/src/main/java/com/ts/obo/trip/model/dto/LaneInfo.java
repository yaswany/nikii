package com.ts.obo.trip.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LaneInfo {

    private Long laneId;                                //LANE_ID	BIGINT PRIMARY KEY,
    private String externLaneId;                        //EXTERN_LANE_ID	VARCHAR(255),
    private String avi;                                 //AVI	VARCHAR(255),
    private Integer operationalMode;                    //OPERATIONAL_MODE	INT,
    private Integer status;                             //STATUS	INT,
    private Integer plazaId;                            //PLAZA_ID	INT,
    private Integer laneIdx;                            //LANE_IDX	INT,
    private Integer laneMask;                           //LANE_MASK	INT,
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTs;                              //UPDATE_TS	TIMESTAMP(2),
    private String direction;                           //DIRECTION	VARCHAR(255),
    private String laneIp;                              //LANE_IP	VARCHAR(255),
    private String portNo;                              //PORT_NO	VARCHAR(255),
    private String hostQueueName;                       //HOST_QUEUE_NAME	VARCHAR(255),
    private Integer laneType;                           //LANE_TYPE	INT,
    private String localPortNo;                         //LOCAL_PORT_NO	VARCHAR(255),
    private String allowDupLogon;                       //ALLOW_DUP_LOGON	VARCHAR(255),
    private String lanePowmgrUrl;                       //LANE_POWMGR_URL	VARCHAR(255),
    private String isLegacy;                            //IS_LEGACY	VARCHAR(255),
    private String isReversible;                        //IS_REVERSIBLE	VARCHAR(255),
    private Integer reversibleLane;                     //REVERSIBLE_LANE	INT,
    private Integer vPlazaId;                           //V_PLAZA_ID	INT,
    private String laneDescr;                           //LANE_DESCR	VARCHAR(255),
    private Integer sortOrder;                          //SORT_ORDER	INT,
    private Integer speedThreshold;                     //SPEED_THRESHOLD	INT,
    private Integer speedThreshold2;                    //SPEED_THRESHOLD2	INT,
    private Integer lanePosNum;                         //LANE_POS_NUM	INT,
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private Date cutOverDate;                           //CUT_OVER_DATE	TIMESTAMP(3),
    private String vpdsEnabled;                         //VPDS_ENABLED	VARCHAR(255),
    private String secondaryLaneIp;
}
