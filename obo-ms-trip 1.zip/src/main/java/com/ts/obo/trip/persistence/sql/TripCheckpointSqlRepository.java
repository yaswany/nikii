package com.ts.obo.trip.persistence.sql;

import com.ts.obo.trip.model.PlazaGetInfo;
import com.ts.obo.trip.model.TripCheckpoint;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Qualifier("TripCheckpointRepository")
@Repository
public interface TripCheckpointSqlRepository extends JpaRepository<TripCheckpoint, Integer> {
}