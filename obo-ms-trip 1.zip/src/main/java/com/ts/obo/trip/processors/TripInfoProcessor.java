package com.ts.obo.trip.processors;

import com.ts.obo.trip.model.TripInfo;
import com.ts.obo.trip.model.kafka.LaneMessage;
import com.ts.obo.trip.parser.TripInfoParser;
import com.ts.obo.trip.persistence.TripInfoRepository;
import com.ts.obo.trip.persistence.TripLaneTxRepository;
import com.ts.obo.trip.util.Incrementor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class TripInfoProcessor extends AbstractProcessor {

    @Autowired
    TripInfoParser tripInfoParser;
    @Autowired
    TripInfoRepository tripInfoRepository;
    @Autowired
    Incrementor incrementor;
    @Autowired
    TripLaneTxRepository tripLaneRepository;


    @Override
    public void process(LaneMessage laneMessage) {

        log.info("I am in infoprocessor");
        TripInfo tripinfo = tripInfoParser.constructMessageHeader(laneMessage);

        Long messageId = tripLaneRepository.getMessageId();
        tripinfo.setMessageId(incrementor.increment(messageId));
        tripInfoRepository.save(tripinfo);
    }
}
