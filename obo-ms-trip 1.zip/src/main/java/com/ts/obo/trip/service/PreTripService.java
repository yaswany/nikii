package com.ts.obo.trip.service;

import com.ts.obo.trip.client.AppClient;
import com.ts.obo.trip.model.PlazaGetInfo;
import com.ts.obo.trip.model.dto.*;
import com.ts.obo.trip.persistence.PlazaGetInfoRepository;
import com.ts.obo.trip.persistence.TripLaneTxRepository;
import com.ts.obo.trip.persistence.TripPlazaRepository;
import com.ts.obo.trip.persistence.TripTxRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static org.aspectj.runtime.internal.Conversions.intValue;

/**
 * The type Pre trip service.
 */
@Slf4j
@Service
public class PreTripService {

    /**
     * The Agency id.
     */
    @Value("${agency.id}")
    int agencyId;

    /**
     * The Img threshold check.
     */
    @Value("${img.threshold.check}")
    int imgThresholdCheck;

    /**
     * The Img rec threshold check.
     */
    @Value("${img.rec.threshold.check}")
    int imgRecThresholdCheck;

    /**
     * The Etc time out threshold.
     */
    @Value("${etc.time.out.threshold}")
    int etcTimeOutThreshold;

    /**
     * The Viol time out threshold.
     */
    @Value("${viol.time.out.threshold}")
    int violTimeOutThreshold;

    /**
     * The Viol time out threshold.
     */
    @Value("${MAX.OVERRIDE.DAYS}")
    int maxOverrideDays;

    /**
     * The Viol time out threshold.
     */
    @Value("${MISSING.IMG.THRESHOLD.DAYS}")
    int missingImgThresholdDays;

    /**
     * The Viol time out threshold.
     */
    @Value("${DEFAULT.DAYS.OVERRIDE.ENABLE}")
    boolean defaultDaysOverrideEnable;

    /**
     * The Viol time out threshold.
     */
    @Value("${DEFAULT.DAYS}")
    int defaultDays;

    /**
     * The Viol time out threshold.
     */
    @Value("${MAX.OVERRIDE.DAYS.ENABLE}")
    boolean maxOverrideDaysEnable;

    /**
     * The App client.
     */
    @Autowired
    AppClient appClient;

    /**
     * The Plaza get info repository.
     */
    @Autowired
    PlazaGetInfoRepository plazaGetInfoRepository;

    /**
     * The Trip lane repository.
     */
    @Autowired
    TripLaneTxRepository tripLaneRepository;

    /**
     * The Trip tx repository.
     */
    @Autowired
    TripTxRepository tripTxRepository;

    @Autowired
    TripPlazaRepository tripPlazaRepository;

    /**
     * The Final trip date.
     */
    Date finalTripDate;
    Date lastFinalTripDate=null;

    /**
     * Pre trip process boolean.
     *
     * @return the boolean
     */
    public boolean preTripProcess(){

        List<TripMessageTimeList> tripMessageTimeList;

        /** List(max_host_value,update_time) */
        tripMessageTimeList=plazaGetInfoRepository.getTripMessageTimeList(agencyId);

        /** update timestamp after get the messageId  */
        tripMessageTimeList.stream().forEach(trip -> {
            TripMessageUpdateDate tripMessageUpdateDate = tripLaneRepository.
                    findMessageAndUpdateDate(trip.getMaxHostValue(),
                            trip.getUpdateTimestamp(),trip.getPlazaId(),agencyId);

            updateTimestamp(tripMessageUpdateDate,trip.getPlazaId());
        });


        /** get list of plazaId based on agencyId from
         * plazaAdmin microservice
         */
        List<PlazaInfoListDTO> lanePlazaList =  tripPlazaRepository.getPlazaInfoList(agencyId);
        lanePlazaList.stream().forEach(trip -> {
            log.debug("Vpds::{}::cav::{}::plazaId::{}::>>",
                    trip.getVpdsEnabled(),trip.getCavEnabled(),trip.getPlazaId());
        });

        getEntryTxDate(agencyId,lanePlazaList);

        return true;
    }

    private void updateTimestamp(TripMessageUpdateDate tripMessageUpdateDate, int plazaId) {

        if (tripMessageUpdateDate.getTxDate() != null) {
            PlazaGetInfo plazaGetInfo = plazaGetInfoRepository.findByPlazaIdAndDataType(plazaId);

            if (plazaGetInfo != null) {
                plazaGetInfo.setUpdateTimestamp(tripMessageUpdateDate.getTxDate());
                plazaGetInfo.setMaxHostValue(tripMessageUpdateDate.getMessageId());
                plazaGetInfoRepository.save(plazaGetInfo);
                log.info("PlazaGetInfo Updated Successfully");
            }
        }
    }

    /**
     * Get entry tx date boolean.
     *
     * @param agencyId      the agency id
     * @param plazaInfoList the plaza info list
     * @return the boolean
     */
    public boolean getEntryTxDate(int agencyId, List<PlazaInfoListDTO> plazaInfoList) {

        Date entryTxDate = tripTxRepository.getEntryTxDate(agencyId);
        log.info("EntryTxDate::{}::", entryTxDate);
        lastFinalTripDate = (calculateDates(defaultDays));

        //Get max entry transaction date
        getMaxEntryTxDate(entryTxDate, agencyId, plazaInfoList);

        return true;
    }

    /**
     * Get max entry tx date boolean.
     *
     * @param entryTxDate   the entry tx date
     * @param agencyId      the agency id
     * @param plazaInfoList the plaza info list
     * @return the boolean
     */
    public void getMaxEntryTxDate(Date entryTxDate, int agencyId, List<PlazaInfoListDTO> plazaInfoList) {

        Date maxEntryTxDate = tripTxRepository.getMaxEntryTxDate(entryTxDate, agencyId);
        log.info("MaxEntryTxDate::{}::", maxEntryTxDate);

        /**Update transaction date */
        updateTxDate(getPlazaId(plazaInfoList), maxEntryTxDate);

        /** Check and update tx_date*/
        checkAndUpdateTxDate(maxEntryTxDate, plazaInfoList);
    }

    /**
     * Check and update tx date boolean.
     *
     * @param maxEntryTxDate the max entry tx date
     * @param plazaInfoList  the plaza info list
     * @return the boolean
     */
    public boolean checkAndUpdateTxDate(Date maxEntryTxDate, List<PlazaInfoListDTO> plazaInfoList) {
        List<DateList> dateList = tripTxRepository.getDatesList(maxEntryTxDate, new Date());

        dateList.stream().forEach(tripDates -> {
            log.debug("dateList:::{}:", tripDates.getDateListInfo());
            calculateImageCount(getViolationImageInfo(tripDates.getDateListInfo(), plazaInfoList),
                    getETCCavImageInfo(tripDates.getDateListInfo(), getCavEnabledPlazaId(plazaInfoList)),
                    getETCVpdsImageInfo(tripDates.getDateListInfo(), getVpdsEnabledPlazaId(plazaInfoList)),
                    getDifferenceDays(tripDates.getDateListInfo(), new Date()),
                    getPlazaId(plazaInfoList), tripDates.getDateListInfo());
        });

        isSendForTripConstruction(getPlazaId(plazaInfoList));

        return true;
    }

    private void isSendForTripConstruction(List<Integer> plazaId) {

        Date minTxDate = plazaGetInfoRepository.getMinTxDate(plazaId, agencyId);
        log.info("Final trip date::{}::",getFinalTripDate());
        log.info("MinTxDate::{}",minTxDate);

        if (getFinalTripDate().compareTo(minTxDate) < 0 || getFinalTripDate().compareTo(minTxDate) == 0) {
            log.info("Send for trip construction");
        } else {
            log.info("Not send for trip construction");
        }
    }

    /**
     * Gets difference days.
     *
     * @param d1 the d 1
     * @param d2 the d 2
     * @return the difference days
     */
    public static long getDifferenceDays(Date d1, Date d2) {
        long diff = d2.getTime() - d1.getTime();
        return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
    }

    /**
     * Get plaza id list.
     *
     * @param plazaInfo the plaza info
     * @return the list
     */
    public List<Integer> getPlazaId(List<PlazaInfoListDTO> plazaInfo) {
        return plazaInfo.stream().map(a -> intValue(a.getPlazaId())).collect(Collectors.toList());
    }

    /**
     * Get cav enabled plaza id list.
     *
     * @param plazaInfo the plaza info
     * @return the list
     */
    public List<Integer> getCavEnabledPlazaId(List<PlazaInfoListDTO> plazaInfo) {
        List<Integer> cavEnabledPlazaId = new ArrayList<>();
        plazaInfo.stream().forEach(trip -> {
            if (trip.getCavEnabled() != null && trip.getCavEnabled().equalsIgnoreCase("Y")) {
                cavEnabledPlazaId.add(trip.getPlazaId());
            }
        });
        return cavEnabledPlazaId;
    }

    /**
     * Get vpds enabled plaza id list.
     *
     * @param plazaInfo the plaza info
     * @return the list
     */
    public List<Integer> getVpdsEnabledPlazaId(List<PlazaInfoListDTO> plazaInfo) {
        List<Integer> vpdsEnabledPlazaId = new ArrayList<>();
        plazaInfo.stream().forEach(trip -> {
            if (trip.getVpdsEnabled() != null && trip.getVpdsEnabled().equalsIgnoreCase("Y")) {
                vpdsEnabledPlazaId.add(trip.getPlazaId());
            }
        });
        return vpdsEnabledPlazaId;
    }

    /**
     * Update tx date.
     *
     * @param plazaId the plaza id
     * @param txDate  the max entry tx date
     */
    public void updateTxDate(List<Integer> plazaId, Date txDate) {

        plazaId.stream().forEach(trip -> {
            PlazaGetInfo info = plazaGetInfoRepository.getTxDate(trip.intValue(), txDate);
            if (info != null) {
                info.setTxDate(txDate);
                plazaGetInfoRepository.save(info);
                log.info("tx_date updated successfully");
            }
        });
    }

    /**
     * Get violation image info violation image info.
     *
     * @param currentTripDate the current trip date
     * @param plazaInfo       the plaza info
     * @return the violation image info
     */
    public ViolationImageInfo getViolationImageInfo(Date currentTripDate, List<PlazaInfoListDTO> plazaInfo) {
        return tripLaneRepository.getViolationImageCount(currentTripDate, getPlazaId(plazaInfo));
    }

    /**
     * Get etc cav image info etc cav image info.
     *
     * @param currentTripDate   the current trip date
     * @param cavEnabledPlazaId the cav enabled plaza id
     * @return the etc cav image info
     */
    public ETCCavImageInfo getETCCavImageInfo(Date currentTripDate, List<Integer> cavEnabledPlazaId) {
        return tripLaneRepository.getETCCavImageCount(currentTripDate, cavEnabledPlazaId);
    }

    /**
     * Get etc vpds image info etc vpds image info.
     *
     * @param currentTripDate    the current trip date
     * @param vpdsEnabledPlazaId the vpds enabled plaza id
     * @return the etc vpds image info
     */
    public ETCVpdsImageInfo getETCVpdsImageInfo(Date currentTripDate, List<Integer> vpdsEnabledPlazaId) {
        return tripLaneRepository.getETCVpdsImageCount(currentTripDate, vpdsEnabledPlazaId);
    }

    /**
     * Calculate image count.
     *
     * @param violationImageInfo the violation image info
     * @param etcCavImageInfo    the etc cav image info
     * @param etcVpdsImageInfo   the etc vpds image info
     * @param daysDifference     the days difference
     * @param plazaId            the plaza id
     * @param dateListInfo       the date list info
     */
    public void calculateImageCount(ViolationImageInfo violationImageInfo, ETCCavImageInfo etcCavImageInfo, ETCVpdsImageInfo etcVpdsImageInfo,
                                    long daysDifference, List<Integer> plazaId, Date dateListInfo) {

        int etcImgTakenCount = etcCavImageInfo.getCavImgTakenCount() + etcVpdsImageInfo.getVpdsImgTakenCount();
        int etcImgRecCount = etcCavImageInfo.getCavImgRecCount() + etcVpdsImageInfo.getVpdsImgRecCount();
        int etcImgRevCount = etcCavImageInfo.getCavImgRevCount() + etcVpdsImageInfo.getVpdsImgRevCount();

        calculateReviewProcess(violationImageInfo, etcImgTakenCount, etcImgRecCount, etcImgRevCount,
                daysDifference, plazaId, dateListInfo);
    }

    /**
     * Calculate review process.
     *
     * @param violationImageInfo the violation image info
     * @param etcImgTakenCount   the etc img taken count
     * @param etcImgRecCount     the etc img rec count
     * @param etcImgRevCount     the etc img rev count
     * @param timeOutCheck       the time out check
     * @param plazaId            the plaza id
     * @param dateListInfo       the date list info
     */
    public void calculateReviewProcess(ViolationImageInfo violationImageInfo, int etcImgTakenCount,
                                       int etcImgRecCount, int etcImgRevCount, long timeOutCheck, List<Integer> plazaId,
                                       Date dateListInfo) {

        int violImgTakenCount = getViolImgTakenCount(violationImageInfo);
        int violImgRecCount = getViolImgRecCount(violationImageInfo);
        int violImgRevCount = getViolImgRevCount(violationImageInfo);
        int reviewProcess = 0;

        if (violImgRevCount != -1 && etcImgRevCount != -1) {
            if (etcImgRecCount == -1 || etcImgRecCount == 0) {
                etcImgRecCount = 1;
            }
            if (etcImgTakenCount == -1 || etcImgTakenCount == 0) {
                etcImgTakenCount = 1;
            }

            if ((((violImgRevCount / violImgRecCount) * 100) > imgThresholdCheck)
                    &&
                    ((((violImgRecCount / violImgTakenCount) * 100) > imgRecThresholdCheck)
                            || (timeOutCheck > violTimeOutThreshold))
                    && (
                    (((etcImgRevCount / etcImgRecCount) * 100) > imgThresholdCheck)
                            &&
                            ((((etcImgRecCount / etcImgTakenCount) * 100) > imgRecThresholdCheck) ||
                                    (timeOutCheck > etcTimeOutThreshold))
            )
            ) {
                reviewProcess = 1;
            }
        }

        if (reviewProcess == 1) {
            updateTxDate(plazaId, dateListInfo);
        }

        calculateFinalTripDate(plazaId, agencyId, dateListInfo);
    }

    private void calculateFinalTripDate(List<Integer> plazaId, int agencyId, Date dateListInfo) {
        Date finalTripDates;

        if (!defaultDaysOverrideEnable) {
            if (dateListInfo.compareTo(calculateDates(defaultDays)) > 0 || dateListInfo.compareTo(calculateDates(defaultDays)) == 0) {
                finalTripDates = (calculateDates(defaultDays)); //  (systemDate - 5)
            } else {
                finalTripDates = dateListInfo;
            }
        } else {
            finalTripDates = dateListInfo;
        }

        if (maxOverrideDaysEnable && finalTripDates.compareTo(calculateDates(maxOverrideDays)) < 0) {
            finalTripDates = (calculateDates(maxOverrideDays));
        }

        if (finalTripDates.compareTo(lastFinalTripDate) > 0 || finalTripDates.compareTo(lastFinalTripDate) == 0) {
            lastFinalTripDate = finalTripDates;
            setFinalTripDate(finalTripDates);
            log.info("Threshold met transaction date::{} ", finalTripDates);
        }
    }

    private void setFinalTripDate(Date ftDate) {
        finalTripDate = ftDate;
    }

    private Date getFinalTripDate() {
        return finalTripDate;
    }

    private Date calculateDates(int defaultDays) {

        LocalDate localDate = Instant.ofEpochMilli((new Date()).getTime()).atZone(ZoneId.systemDefault()).toLocalDate();

        LocalDate defaultDaysDate = localDate.minusDays(defaultDays);
        return Date.from(defaultDaysDate.atStartOfDay().atZone(ZoneId.systemDefault())
                .toInstant());
    }

    private int getViolImgRecCount(ViolationImageInfo violationImageInfo) {
        if (violationImageInfo.getViolImgRecCount() == -1 || violationImageInfo.getViolImgRecCount() == 0) {
            return 1;
        }
        return violationImageInfo.getViolImgRecCount();
    }

    private int getViolImgRevCount(ViolationImageInfo violationImageInfo) {
        if (violationImageInfo.getViolImgRevCount() == -1 || violationImageInfo.getViolImgRevCount() == 0) {
            return 1;
        }
        return violationImageInfo.getViolImgRevCount();
    }

    private int getViolImgTakenCount(ViolationImageInfo violationImageInfo) {
        if (violationImageInfo.getViolImgTakenCount() == -1 || violationImageInfo.getViolImgTakenCount() == 0) {
            return 1;
        }
        return violationImageInfo.getViolImgTakenCount();
    }

}
