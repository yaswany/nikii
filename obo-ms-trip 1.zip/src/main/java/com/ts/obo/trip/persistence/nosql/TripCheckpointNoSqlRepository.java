package com.ts.obo.trip.persistence.nosql;

import com.ts.obo.trip.model.PlazaGetInfo;
import com.ts.obo.trip.model.TripCheckpoint;
import com.ts.obo.trip.persistence.PlazaGetInfoRepository;
import com.ts.obo.trip.persistence.TripCheckpointRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Qualifier("TripCheckpointRepository")
@Repository
public interface TripCheckpointNoSqlRepository extends CrudRepository<TripCheckpoint, Integer>, TripCheckpointRepository {
}