package com.ts.obo.trip.model.dto;

public interface ETCCavImageInfo {

    int getCavImgTakenCount();
    int getCavImgRecCount();
    int getCavImgRevCount();
}
