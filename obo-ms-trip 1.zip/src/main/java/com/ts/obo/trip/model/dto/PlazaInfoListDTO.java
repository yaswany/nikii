package com.ts.obo.trip.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

public interface PlazaInfoListDTO {

    int getPlazaId();
    String getCavEnabled();
    String getVpdsEnabled();
}
