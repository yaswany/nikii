package com.ts.obo.trip.parser;

import com.ts.obo.trip.client.AppClient;
import com.ts.obo.trip.model.dto.PlazaInfo;
import com.ts.obo.trip.model.dto.PlazaLaneInfo;
import com.ts.obo.trip.model.kafka.LaneMessage;
import com.ts.obo.trip.persistence.TripLaneRepository;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class AbstractParser {

    @Autowired
    TripLaneRepository tripLaneRepository;

    public PlazaLaneInfo getPlazaLaneInfo(LaneMessage laneMessage){
        return tripLaneRepository.getInfo(laneMessage.getPlazaId(),laneMessage.getLaneId());
    }
}
