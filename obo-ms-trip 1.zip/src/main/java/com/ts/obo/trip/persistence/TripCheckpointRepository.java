package com.ts.obo.trip.persistence;

public interface TripCheckpointRepository {
}
