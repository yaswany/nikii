package com.ts.obo.trip.util;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

import java.io.IOException;

/**
 * The type Json mapper.
 */
@Slf4j
public class JsonMapper {

    private final static ObjectMapper mapper = new ObjectMapper();

    /**
     * To json string.
     *
     * @param object the object
     * @return the string
     */
    public static String toJson(Object object) {
        log.info("MAPPER : JsonMapper : toJson...!!!");
        String json = null;
        try {
            json = mapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            log.error("Error while converting object to json string : {}" , e.getMessage(), e);
        }
        return json;
    }

    /**
     * To object t.
     *
     * @param <T>        the type parameter
     * @param jsonString the json string
     * @param object     the object
     * @return the t
     */
    public static <T> T toObject(String jsonString, Class<T> object) {
        log.info("MAPPER : JsonMapper : toObject...!!!");
        try {

            // configure ignore unknown properties
            mapper.configure(DeserializationFeature
                            .FAIL_ON_UNKNOWN_PROPERTIES,
                    false);

            return mapper.readValue(jsonString, object);
        } catch (JsonParseException e) {
            log.error("Error while converting json to object : {}",e.getMessage(), e);
        } catch (JsonMappingException e) {
            log.error("Error while converting json to object : {}",e.getMessage(), e);
        } catch (IOException e) {
            log.error("Error while converting json to object : {}",e.getMessage(), e);
        }
        return null;
    }
}
