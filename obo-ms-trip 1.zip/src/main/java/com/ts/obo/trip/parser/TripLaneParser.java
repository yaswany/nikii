package com.ts.obo.trip.parser;

import com.ts.obo.trip.model.TripLane;
import com.ts.obo.trip.model.dto.LaneInfo;
import com.ts.obo.trip.persistence.TripLaneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class TripLaneParser {

    @Autowired
    TripLaneRepository tripLaneRepository;

    public void constructMessageHeader(List<LaneInfo> laneInfo){

        TripLane tripLane = new TripLane();

        laneInfo.stream().forEach(lane -> {

            tripLane.setLaneId(lane.getLaneId());
            tripLane.setExternLaneId(lane.getExternLaneId());
            tripLane.setAvi(lane.getAvi());
            tripLane.setOperationalMode(lane.getOperationalMode());
            tripLane.setStatus(lane.getStatus());                           //STATUS	INT,
            tripLane.setPlazaId(lane.getPlazaId());                          //PLAZA_ID	INT,
            tripLane.setLaneIdx(lane.getLaneIdx());                            //LANE_IDX	INT,
            tripLane.setLaneMask(lane.getLaneMask());                          //LANE_MASK	INT,
            tripLane.setUpdateTs(lane.getUpdateTs());                             //UPDATE_TS	TIMESTAMP(2),
            tripLane.setDirection(lane.getDirection());                           //DIRECTION	VARCHAR(255),
            tripLane.setLaneIp(lane.getLaneIp());                             //LANE_IP	VARCHAR(255),
            tripLane.setPortNo(lane.getPortNo());                             //PORT_NO	VARCHAR(255),
            tripLane.setHostQueueName(lane.getHostQueueName());                       //HOST_QUEUE_NAME	VARCHAR(255),
            tripLane.setLaneType(lane.getLaneType());                         //LANE_TYPE	INT,
            tripLane.setLocalPortNo(lane.getLocalPortNo());                      //LOCAL_PORT_NO	VARCHAR(255),
            tripLane.setAllowDupLogon(lane.getAllowDupLogon());                       //ALLOW_DUP_LOGON	VARCHAR(255),
            tripLane.setLanePowmgrUrl(lane.getLanePowmgrUrl());                       //LANE_POWMGR_URL	VARCHAR(255),
            tripLane.setIsLegacy(lane.getIsLegacy());                          //IS_LEGACY	VARCHAR(255),
            tripLane.setIsReversible(lane.getIsReversible());                        //IS_REVERSIBLE	VARCHAR(255),
            tripLane.setReversibleLane(lane.getReversibleLane());                   //REVERSIBLE_LANE	INT,
            tripLane.setVPlazaId(lane.getVPlazaId());                          //V_PLAZA_ID	INT,
            tripLane.setLaneDescr(lane.getLaneDescr());                          //LANE_DESCR	VARCHAR(255),
            tripLane.setSortOrder(lane.getSortOrder());                         //SORT_ORDER	INT,
            tripLane.setSpeedThreshold(lane.getSpeedThreshold());                     //SPEED_THRESHOLD	INT,
            tripLane.setSpeedThreshold2(lane.getSpeedThreshold2());                    //SPEED_THRESHOLD2	INT,
            tripLane.setLanePosNum(lane.getLanePosNum());                         //LANE_POS_NUM	INT,
            tripLane.setCutOverDate(lane.getCutOverDate());                          //CUT_OVER_DATE	TIMESTAMP(3),
            tripLane.setVpdsEnabled(lane.getVpdsEnabled());                        //VPDS_ENABLED	VARCHAR(255),
            tripLane.setSecondaryLaneIp(lane.getSecondaryLaneIp());

            tripLaneRepository.save(tripLane);
        });

    }
}
