package com.ts.obo.trip.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "t_plaza_get_info")
public class PlazaGetInfo implements Serializable {

    private Integer plazaId;
    @Id
    long maxHostValue;
    long recordsInserted;
    String dataType;
    Date updateTimestamp;
    Integer agencyId;
    String migrFlag;
    Date txDate;

}
