package com.ts.obo.trip.trip;

import com.ts.obo.trip.service.PreTripStarter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class PreTripScheduler {

    @Autowired
    PreTripStarter preTripStarter;

    /**
     * This scheduler will run only once a day
     * But for development purpose run 30 minutes once
     */
    @Scheduled(cron = "0 0/30 * * * ?") // Every 30 minutes //
    public void preTripStart() {

        try {
            log.info("pre-trip process");
            preTripStarter.startPreTripProcess();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
