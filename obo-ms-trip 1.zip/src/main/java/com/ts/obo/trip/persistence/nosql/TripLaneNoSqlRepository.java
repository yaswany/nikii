package com.ts.obo.trip.persistence.nosql;

import com.ts.obo.trip.model.TripLane;
import com.ts.obo.trip.persistence.TripLaneRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Qualifier("TripLaneRepository")
@Repository
public interface TripLaneNoSqlRepository extends CrudRepository<TripLane, Integer>, TripLaneRepository {
}