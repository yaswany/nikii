package com.ts.obo.trip.persistence;

import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.io.Serializable;

@NoRepositoryBean
public interface ITransportationRepository<T extends Serializable, ID extends Serializable> extends
        PagingAndSortingRepository<T,ID> {

}
