package com.ts.obo.trip.persistence;

import com.ts.obo.trip.model.PlazaGetInfo;
import com.ts.obo.trip.model.dto.TripMessageTimeList;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.Date;
import java.util.List;

@NoRepositoryBean
public interface PlazaGetInfoRepository extends ITransportationRepository<PlazaGetInfo, Integer> {

    @Query
    PlazaGetInfo findByPlazaIdAndDataType(int plazaId);

    @Query
    PlazaGetInfo getTxDate(int plazaId, Date maxEntryTxDate);

    @Query
    Date getMinTxDate(List<Integer> plazaId,int agencyId);

    @Query(nativeQuery = true)
    List<TripMessageTimeList> getTripMessageTimeList(int agencyId);
}
