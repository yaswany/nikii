package com.ts.obo.trip.persistence;

import com.ts.obo.trip.model.TripPlaza;
import com.ts.obo.trip.model.dto.PlazaInfoListDTO;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.List;

@NoRepositoryBean
public interface TripPlazaRepository extends ITransportationRepository<TripPlaza, Long> {

    @Query
    List<PlazaInfoListDTO> getPlazaInfoList(int agencyId);
}