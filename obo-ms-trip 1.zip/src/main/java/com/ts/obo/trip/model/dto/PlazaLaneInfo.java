package com.ts.obo.trip.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlazaLaneInfo {

    Long plazaId;
    Long laneId;
}
