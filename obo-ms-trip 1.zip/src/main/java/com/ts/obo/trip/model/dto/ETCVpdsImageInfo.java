package com.ts.obo.trip.model.dto;

public interface ETCVpdsImageInfo {

    int getVpdsImgTakenCount();
    int getVpdsImgRecCount();
    int getVpdsImgRevCount();
}
