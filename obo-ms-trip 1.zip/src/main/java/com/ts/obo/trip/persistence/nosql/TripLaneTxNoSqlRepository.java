package com.ts.obo.trip.persistence.nosql;

import com.ts.obo.trip.model.TripLaneTx;
import com.ts.obo.trip.persistence.TripLaneTxRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Qualifier("TripLaneTxRepository")
@Repository
public interface TripLaneTxNoSqlRepository extends CrudRepository<TripLaneTx, Integer>, TripLaneTxRepository {
}
