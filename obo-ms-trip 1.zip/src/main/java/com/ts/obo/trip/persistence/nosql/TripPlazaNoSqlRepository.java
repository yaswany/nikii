package com.ts.obo.trip.persistence.nosql;

import com.ts.obo.trip.model.TripPlaza;
import com.ts.obo.trip.persistence.TripPlazaRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Qualifier("TripPlazaRepository")
@Repository
public interface TripPlazaNoSqlRepository extends CrudRepository<TripPlaza, Long>, TripPlazaRepository {
}