package com.ts.obo.management.device.persistence.sql;

import com.ts.obo.management.device.model.MomsMessageMapping;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * The interface Moms message mapping repository.
 */
@Qualifier("MomsMessageMappingRepository")
@Repository
public interface MomsMessageMappingSqlRepository extends JpaRepository<MomsMessageMapping, Integer> {

}
