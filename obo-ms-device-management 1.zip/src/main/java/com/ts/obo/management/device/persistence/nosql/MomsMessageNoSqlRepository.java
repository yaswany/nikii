package com.ts.obo.management.device.persistence.nosql;

import com.ts.obo.management.device.model.MomsMessage;
import com.ts.obo.management.device.persistence.MomsMessageRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


/**
 * The interface Moms message repository.
 */
@Qualifier("MomsMessageRepository")
@Repository
public interface MomsMessageNoSqlRepository extends CrudRepository<MomsMessage, Integer>, MomsMessageRepository {

}
