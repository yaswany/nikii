package com.ts.obo.management.device.model;

import lombok.Data;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Data
@Component
@Table(name = "t_moms_message_mapping")
public class MomsMessageMapping implements Serializable {

    @Id
    int repairNumber;
    int equipmentId;
    String msgCode;
    int msgThreshold;
    int msgTimeLimit;

}
