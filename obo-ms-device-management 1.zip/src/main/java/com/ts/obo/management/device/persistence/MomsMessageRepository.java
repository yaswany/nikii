package com.ts.obo.management.device.persistence;

import com.ts.obo.management.device.model.MomsMessage;
import com.ts.obo.management.device.model.dto.MomsMessageWorkOrders;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


/**
 * The interface Moms message repository.
 */
@NoRepositoryBean
public interface MomsMessageRepository extends ITransportationRepository<MomsMessage, Integer> {

    MomsMessage findByAlarmId(Integer alarmId);

    @Query
    MomsMessage findMomsMessageForOpenWO(int equipId, int alarmId, int plazaId, int laneId);
    @Query
    MomsMessage findMomsMessageForCloseWO(int equipId, int alarmId, int plazaId, int laneId);

    @Query
    MomsMessage findByMsgCodeForOpen(String msgCode);

    @Query
    MomsMessage findByMsgCodeForClose(String msgCode);

    @Transactional
    @Query
    List<MomsMessageWorkOrders> getAllWorkOrders(int pageSize, List<Integer> plazaId, List<Integer> laneId);
}

