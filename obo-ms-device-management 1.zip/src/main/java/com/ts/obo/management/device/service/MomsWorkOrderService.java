package com.ts.obo.management.device.service;

import com.ts.obo.management.device.client.AppClient;
import com.ts.obo.management.device.exception.ErrorType;
import com.ts.obo.management.device.exception.OBOException;
import com.ts.obo.management.device.model.dto.MomsCMMSWorkOrder;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Slf4j
@Service
public class MomsWorkOrderService {
	
	@Value( "${cmms.end.point.url}" )
	private String momsURL;
	
	@Value( "${cmms.end.point.username}" )
	private String momsUsername;
	
	@Value( "${cmms.end.point.password}" )
	private String momsPassword;

	// How many records to fetch and process at a time information
	@Value( "${moms.process.page.size}" )
	private String pageSize;
	
	@Value("${type.value}")
	private String typeValue;
	@Value("${type.description}")
	private String typeDescription;
	
	@Value("${status.value}")
	private String statusValue;
	@Value("${status.description}")
	private String statusDescription;
	
	@Value("${close.status.value}")
	private String closeStatusValue;
	@Value("${close.status.description}")
	private String closeStatusDescription;
	
	@Value("${priority.value}")
	private String priorityValue;
	@Value("${priority.description}")
	private String priorityDescription;
	
	@Value("${repair.center.pk}")
	private String repairCenterPk;
	@Value("${repair.center.id}")
	private String repairCenterId;
	@Value("${repair.center.name}")
	private String repairCenterName;

	String plazaLaneId;

	@Autowired
	MomsMessageServiceImpl momsMessageServiceImpl;

	@Autowired
	AppClient appClient;
	
	public void processWOCreation(String pageSizeParam) throws Exception {

		if(pageSizeParam != null)
			pageSize = pageSizeParam;
		
		log.info("The Page Size :: "+ pageSize);
		if(pageSize == null)
			pageSize = "5";

		List<MomsCMMSWorkOrder> list = momsMessageServiceImpl.getAllWorkOrders(Integer.parseInt(pageSize));

		for(MomsCMMSWorkOrder momsTx : list) {

			JSONArray woa = new JSONArray();
			JSONObject wo = new JSONObject();
			JSONObject typeDetails = new JSONObject();
			JSONObject statusDetails = new JSONObject();
			JSONObject priorityDetails = new JSONObject();
			JSONObject repairCenterRef = new JSONObject();
			JSONObject failureRef = new JSONObject();
			JSONObject assetRef = new JSONObject();
			try {
				LocalDateTime time = LocalDateTime.now();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
				String requestDate = formatter.format(time);
				requestDate = requestDate.replaceAll(" ", "T");

				log.info("CloseSentFlag::{},OpenSentFlag::{},WoNumber::{},Description::{}:::",
						momsTx.getCloseSentFlag(),momsTx.getOpenSentFlag(),
						momsTx.getWoNumber(),momsTx.getDescription());

				if(momsTx.getCloseSentFlag() == 0 && momsTx.getOpenSentFlag() ==  1) {

					if(momsTx.getWoNumber()<= 0) continue;

					wo.put("PK", String.valueOf(momsTx.getWoNumber()));
					wo.put("ID", String.valueOf(momsTx.getWoNumber()));

					statusDetails.put("Value", closeStatusValue);
					statusDetails.put("Description", closeStatusDescription);

					wo.put("StatusDetails", statusDetails);

					woa.put(wo);
				} else if(momsTx.getOpenSentFlag()==0) {
					if(momsTx.getWoNumber()> 0) continue;

					wo.put("Reason", momsTx.getDescription());
					wo.put("RequestedDate", requestDate);

					typeDetails.put("Value", typeValue);
					typeDetails.put("Description", typeDescription);

					repairCenterRef.put("ID",repairCenterId);
					repairCenterRef.put("Name",repairCenterName);

					plazaLaneId = momsTx.getExternalPlazaId().concat(momsTx.getExternalLaneId());
					assetRef.put("PK", 1001);
					assetRef.put("ID", plazaLaneId);
					assetRef.put("Name", momsTx.getPlazaName());

					failureRef.put("ID",String.valueOf(momsTx.getAlarmId()));

					statusDetails.put("Value", statusValue);
					statusDetails.put("Description", statusDescription);

					priorityDetails.put("Value", priorityValue);
					priorityDetails.put("Description", priorityDescription);

					wo.put("TypeDetails", typeDetails);
					wo.put("StatusDetails", statusDetails);
					wo.put("PriorityDetails", priorityDetails);
					wo.put("RepairCenterRef", repairCenterRef);
					wo.put("ProblemRef", failureRef);
					wo.put("AssetRef", assetRef);
					log.info("Data::{}  ",wo.names());
					woa.put(wo);
				}

				JSONObject result = null;
				if(momsTx.getOpenSentFlag() ==  0) {

					result = appClient.callMOMSWoOpen(momsURL, momsUsername, momsPassword, woa);
					log.info(result.toString());

					JSONObject res = (JSONObject)((JSONArray)result.get("Results")).get(0);
					log.info("Work Order No Received :: "+(res.getInt("PK")));

					momsMessageServiceImpl.updateOpenWO( res.getInt("PK"),
							momsTx.getEquipId(), momsTx.getAlarmId(),
							momsTx.getPlazaId(), momsTx.getLaneId());

				} else if(momsTx.getCloseSentFlag() == 0 && momsTx.getOpenSentFlag() ==  1){
					result = appClient.callMOMSWoClose(momsURL, momsUsername, momsPassword, woa);
					log.info(result.toString());

					JSONObject res = (JSONObject)((JSONArray)result.get("Results")).get(0);
					log.info("Work Order No Received :: "+(res.getInt("PK")));
					momsMessageServiceImpl.updateCloseWO(
							momsTx.getEquipId(), momsTx.getAlarmId(),
							momsTx.getPlazaId(),momsTx.getLaneId());

				}else {
					log.info("Invalid state of Workorder - OPEN SENT FLAG {}::CLOSE SENT FLAG ::{} "
							,momsTx.getOpenSentFlag(),momsTx.getCloseSentFlag());
				}

			} catch (Exception exception) {
				throw new OBOException(exception.getMessage(), ErrorType.ApplicationError,exception.getCause());
			}
		}
	
	}

}
