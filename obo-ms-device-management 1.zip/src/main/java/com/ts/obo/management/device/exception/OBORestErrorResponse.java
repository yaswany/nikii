package com.ts.obo.management.device.exception;

import lombok.Data;
import org.springframework.http.HttpStatus;

import java.time.LocalDateTime;

@Data
public class OBORestErrorResponse {
    private LocalDateTime timestamp;
    private String message;
    private String type;
    private HttpStatus status;
}
