package com.ts.obo.management.device.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PlazaLaneListDTO {
     int laneId;              // internalLaneId
     String externLaneId;     // externalPlazaId
     int plazaId;             // internalPlazaId
     String externPlazaId;    // externalLaneId
     String name;             // plazaName

}