package com.ts.obo.management.device.persistence.sql;

import com.ts.obo.management.device.model.MomsMessage;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


/**
 * The interface Moms message repository.
 */
@Qualifier("MomsMessageRepository")
@Repository
public interface MomsMessageSqlRepository extends JpaRepository<MomsMessage, Integer> {

}
