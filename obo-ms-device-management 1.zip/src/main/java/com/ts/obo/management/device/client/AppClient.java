package com.ts.obo.management.device.client;

import com.ts.obo.management.device.model.dto.PlazaLaneListDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.codec.binary.Base64;
import org.json.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;

/**
 * The type App client.
 */
@Slf4j
@Component
public class AppClient {

    /**
     * The Base url.
     */
    @Value("${rest.endpoint.laneUrl}")
    String laneUrl;

    @Value("${cmms.end.point.url}")
    String baseUrlNew;

    @Autowired
    RestTemplate restTemplate;

    /**
     * Gets lane and plaza info.
     *
     * @return the lane and plaza info
     */
    @Cacheable(cacheNames = "OBOCache")
    public ResponseEntity<String> getLanePlazaId() {

            String restEndPointURL = laneUrl+"/moms";
            var headers = new HttpHeaders();
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
            HttpEntity<String> entity = new HttpEntity<>(headers);
            return getRestTemplate().exchange(restEndPointURL, HttpMethod.GET, entity, String.class);

    }

    /**
     * Gets lane and plaza list.
     *
     * @return the lane and plaza list
     */
    @Cacheable(cacheNames = "OBOCache")
    public List<PlazaLaneListDTO> getLaneAndPlazaList()  {

        String restEndPointURL = laneUrl+"/plaza-lane-list";
        var headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<PlazaLaneListDTO[]> lanePlazaDetails=
                getRestTemplate().exchange(restEndPointURL, HttpMethod.GET, entity,
                PlazaLaneListDTO[].class);
        return new ArrayList(List.of(lanePlazaDetails.getBody()));
    }

    /**
     * Get rest template rest template.
     *
     * @return the rest template
     */
    public RestTemplate getRestTemplate(){
        return new RestTemplate();
    }


    /**
     * Call moms wo open json object for open work order.
     *
     * @param baseUrl   the base url
     * @param userName  the user name
     * @param password  the password
     * @param workOrder the work order
     * @return the json object
     * @throws Exception the exception
     */
    public JSONObject callMOMSWoOpen(String baseUrl, String userName, String password,
                                     JSONArray workOrder) throws Exception {
        baseUrl = baseUrl+"/workorders";
        log.info("URL:::::"+baseUrlNew);
        URI uri = null;
        try {
            uri = new URI(baseUrl);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

        log.info("URI ::"+uri);
        log.info("BODY :: ");
        int spacesToIndentEachLevel = 2;
        log.info(workOrder.toString(spacesToIndentEachLevel));

        HttpHeaders headers = getHeaders(userName, password);
        HttpEntity<String> request =
                new HttpEntity<String>(workOrder.toString(), headers);

        ResponseEntity<String> result = null;
        try {
            result = getRestTemplate().exchange
                    (baseUrl, HttpMethod.GET, request, String.class);
        }catch(RestClientException rce) {
            log.error("Exception {}",rce);
            throw new Exception(rce.getMessage());
        }

        return new JSONObject(result.getBody());
    }

    /**
     * Call moms wo close json object for close work order..
     *
     * @param baseUrl   the base url
     * @param userName  the user name
     * @param password  the password
     * @param workOrder the work order
     * @return the json object
     * @throws Exception the exception
     */
    public JSONObject callMOMSWoClose(String baseUrl, String userName, String password,
                                      JSONArray workOrder) throws Exception {
        baseUrl = baseUrl+"/workorders";
        URI uri = null;
        try {
            uri = new URI(baseUrl);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

        log.info("URI ::"+uri);
        log.info("BODY :: ");
        int spacesToIndentEachLevel = 2;
        log.info(workOrder.toString(spacesToIndentEachLevel));

        HttpHeaders headers = getHeaders(userName, password);

        HttpEntity<String> request =
                new HttpEntity<String>(workOrder.toString(), headers);

        ResponseEntity<String> result = null;
        try {
            result = getRestTemplate().exchange
                    (uri, HttpMethod.PUT, request, String.class);
        } catch(RestClientException rce) {
            //log.error(rce.getMessage());
            throw new Exception(rce.getMessage());
        }

        return new JSONObject(result.getBody());
    }

    private HttpHeaders getHeaders(String username, String password){
        return new HttpHeaders() {{
            set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
            set("Accept", MediaType.APPLICATION_JSON_VALUE);
            String auth = "TEST" + ":" + "3a033302-f43d-4853-86a3-fca78c6e4cf2";
            byte[] encodedAuth = Base64.encodeBase64(
                    auth.getBytes(Charset.forName("US-ASCII")) );
            String authHeader = "Basic " + new String( encodedAuth );
            set( "Authorization", authHeader );
        }};
    }
}
