package com.ts.obo.management.device.kafka;


import com.ts.obo.management.device.service.MomsMessageServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

/**
 * The type Kafka file name listener.
 */
@Slf4j
@Component
@KafkaListener(id = "class-level", topics = "${kafka.moms.topic_name}", groupId = "${kafka.group_id}")
public class KafkaFileMomsMessageListener {

    @Autowired
    MomsMessageServiceImpl momsMessageService;

    @KafkaHandler
    public void listen(@Payload String message) {

        if (message != null) {
            log.info("Kafka Message from MomsMessageListener ::{} ", message);
            /* Start Unzip process*/
            momsMessageService.insertAndUpdateMomsMessageTx(message);
        }
    }
}