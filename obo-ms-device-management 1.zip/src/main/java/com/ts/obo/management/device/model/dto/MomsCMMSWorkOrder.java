package com.ts.obo.management.device.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MomsCMMSWorkOrder {

    private int plazaId; // internalPlazaId
    private int laneId;  // internalPlazaId
    private int equipId;
    private int alarmId;
    private String description;
    private String woStatus;
    private int woNumber;
    private int openSentFlag;
    private int closeSentFlag;

    private String externalPlazaId; // externalPlazaId
    private String externalLaneId;  // externalLaneId
    private String plazaName;

}
