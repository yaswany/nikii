package com.ts.obo.management.device.model;

import lombok.Data;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@Component
@Table(name = "t_moms_message_tx")
public class MomsMessage implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long momsTxId;
    int  plazaId; // internalPlazaId
    int  laneId;  // internalLaneId
    Date txDate;
    String  messageCode;
    Date updateTs;
    int  sentFlag;
    Date sentTs;
    int  equipId;
    int  alarmId;
    String  description;
    int woNumber;
    String woStatus;
    int openSentFlag;
    int closeSentFlag;
    Date openSentTs;
    Date closeSentTs;
    Date woStartTime;
    Date woEndTime;
}
