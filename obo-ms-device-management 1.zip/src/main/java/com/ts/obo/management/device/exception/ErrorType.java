package com.ts.obo.management.device.exception;

public enum ErrorType {
    ApplicationError(101),
    DatabaseError(102),   // allErrors related to database
    ConnectionError(103), // unable to connect to database/kafka/minio/ms
    ValidationError(104),
    CMMSError(105),
    BPOError(106),
    BOError(107),
    LDAPError(108),
    OCRError(109),
    KafkaError(110),
    MinioError(111),       // bucket/file not available
    SecurityError(112),    // for all external services with wrong userId and password
    OBOMsError(113),       // communication between micro services
    IOError(114),          // local file system error
    NoDataError(115),      //
    InternalError(116);    // This is not an error, it the only return NO_CONTENT HTTP response

    int code;

    ErrorType(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}
