package com.ts.obo.management.device.client;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;

import java.io.IOException;


@SpringBootTest(classes=AppClient.class)
@ExtendWith(MockitoExtension.class)
@TestPropertySource("classpath:/application-test.properties")
class AppClientTest {

    @InjectMocks
    @Autowired
    private AppClient appClientTest;

    public static MockWebServer mockWebServer;
    static String  laneUrl;

    @BeforeEach
    void setUp() throws IOException {
        mockWebServer = new MockWebServer();
        mockWebServer.start(8080);

        laneUrl = String.format("http://localhost:"+ mockWebServer.getPort()+"/api/obo/admin/plaza/");

    }

   // @Test
    void getLanePlazaIdTest() {

      String expected = "200";
        mockWebServer.enqueue(new MockResponse().setBody(expected)
                .addHeader("Content-Type", "application/json").setResponseCode(200));

        ResponseEntity<String> actual = appClientTest.getLanePlazaId();
        Assertions.assertEquals(expected, String.valueOf(actual.getStatusCodeValue()));
    }
}