package com.ts.obo.management.device.exception;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith(MockitoExtension.class)
class OBOExceptionTest {

    private OBOException oboException;

    @Test
    void testNoArgConstructor(){
        oboException = new OBOException();
        Assertions.assertInstanceOf(OBOException.class,oboException);
    }

    @Test
    void testAllArgsConstructor(){
        oboException = new OBOException("OBO Exception",
                ErrorType.ApplicationError);
        Assertions.assertInstanceOf(OBOException.class,oboException);
    }

    @Test
    void testAllArgConstructor(){
        oboException = new OBOException("OBO Exception",
                ErrorType.ApplicationError);
        Assertions.assertEquals("ApplicationError : OBO Exception", oboException.getLocalizedMessage());
    }
}