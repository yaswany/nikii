package com.ts.obo.management.device;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class MainTest {

    @Test
    void contextLoads() {
        Assertions.assertDoesNotThrow(this::doNotThrowException);
    }
    private void doNotThrowException(){
        //This method will never throw exception
    }

}