package com.ts.obo.management.device.service;

import com.ts.obo.management.device.client.AppClient;
import com.ts.obo.management.device.exception.OBOException;
import com.ts.obo.management.device.model.LanePlazaInfo;
import com.ts.obo.management.device.model.MomsMessage;
import com.ts.obo.management.device.persistence.MomsMessageRepository;
import com.ts.obo.management.device.util.JsonMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MomsMessageServiceImplTest {

    @InjectMocks
    private MomsMessageServiceImpl momsMessageServiceTest;

    @Mock
    MomsMessageRepository mockMomsMessageRepository;

    @Mock
    AppClient mockAppClient;

    @Mock
    JsonMapper  jsonMapper;


//   @ParameterizedTest
//   @ValueSource(ints = {1,2,3,4})
    //@Test
    void setAlarmIdAsOneAndInsertMomsMessage(){
        MomsMessage momsMessage = new MomsMessage();
        momsMessage.setMomsTxId(1L);
        momsMessage.setPlazaId(0);
        momsMessage.setLaneId(0);
        momsMessage.setTxDate(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        momsMessage.setMessageCode("message_code");
        momsMessage.setUpdateTs(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        momsMessage.setSentFlag(0);
        momsMessage.setSentTs(new Date());
        momsMessage.setEquipId(0);
        momsMessage.setAlarmId(1);
        momsMessage.setDescription("Invalid plaza lane_id in image file");
        when(mockMomsMessageRepository.findByAlarmId(1)).thenReturn(null);
        verify(mockMomsMessageRepository, Mockito.times(1)).findByAlarmId(1);
    }
   // @Test
    void setAlarmIdAsTwoAndInsertMomsMessage() throws OBOException {
        MomsMessage momsMessage = new MomsMessage();
        momsMessage.setMomsTxId(1L);
        momsMessage.setPlazaId(0);
        momsMessage.setLaneId(0);
        momsMessage.setTxDate(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        momsMessage.setMessageCode("message_code");
        momsMessage.setUpdateTs(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        momsMessage.setSentFlag(0);
        momsMessage.setSentTs(new Date());
        momsMessage.setEquipId(0);
        momsMessage.setAlarmId(2);
        momsMessage.setDescription("Invalid plaza lane_id in image file");
        Mockito.when(mockMomsMessageRepository.findByAlarmId(2)).thenReturn(null);
        verify(mockMomsMessageRepository, Mockito.times(1)).findByAlarmId(2);
    }


    void setAlarmIdAsThreeAndInsertMomsMessage() throws OBOException{

        MomsMessage momsMessage = new MomsMessage();
        momsMessage.setMomsTxId(1L);
        momsMessage.setPlazaId(0);
        momsMessage.setLaneId(0);
        momsMessage.setTxDate(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        momsMessage.setMessageCode("message_code");
        momsMessage.setUpdateTs(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        momsMessage.setSentFlag(0);
        momsMessage.setSentTs(new Date());
        momsMessage.setEquipId(0);
        momsMessage.setAlarmId(3);
        momsMessage.setDescription("Plaza distributor job failed");
        Mockito.when(mockMomsMessageRepository.findByAlarmId(3)).thenReturn(null);
        verify(mockMomsMessageRepository, Mockito.times(1)).findByAlarmId(3);
    }


    void setAlarmIdAsFourAndInsertMomsMessage() throws OBOException{

        MomsMessage momsMessage = new MomsMessage();
        momsMessage.setMomsTxId(1L);
        momsMessage.setPlazaId(0);
        momsMessage.setLaneId(0);
        momsMessage.setTxDate(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        momsMessage.setMessageCode("message_code");
        momsMessage.setUpdateTs(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        momsMessage.setSentFlag(0);
        momsMessage.setSentTs(new Date());
        momsMessage.setEquipId(0);
        momsMessage.setAlarmId(4);
        momsMessage.setDescription("No VDF/ODF files or no content in VDF/ODF files");
        Mockito.when(mockMomsMessageRepository.findByAlarmId(4)).thenReturn(null);

        verify(mockMomsMessageRepository, Mockito.times(1)).findByAlarmId(4);
    }




    void testInsertMomsMessage() throws OBOException {
        String result = "MomsMessage(momsTxId=1, plazaId=900, laneId=0, txDate=null, messageCode=null, updateTs=null, sentFlag=0, sentTs=null, equipId=0, alarmId=1, description=Invalid plaza lane_id in image file ET0100_20211013212349003DNE.zip)";

        MomsMessage momsMessage = new MomsMessage();
        momsMessage.setMomsTxId(1L);
        momsMessage.setPlazaId(0);
        momsMessage.setLaneId(0);
        momsMessage.setTxDate(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        momsMessage.setMessageCode("message_code");
        momsMessage.setUpdateTs(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        momsMessage.setSentFlag(0);
        momsMessage.setSentTs(new Date());
        momsMessage.setEquipId(0);
        momsMessage.setAlarmId(3);
        momsMessage.setDescription("Invalid plaza lane_id in image file");
        when(mockMomsMessageRepository.findByAlarmId(3)).thenReturn(null);
        Mockito.when(mockAppClient.getLanePlazaId()).thenReturn(new ResponseEntity(result, HttpStatus.OK));
        verify(mockMomsMessageRepository, Mockito.times(1)).findByAlarmId(3);
    }


    void testInsertMomsMessageValidPlaza() throws OBOException {
        String result = "{\"plazaId\": 900, \"laneId\" : 2000}";
        LanePlazaInfo info = new LanePlazaInfo();
        info.setPlazaId(900);
        info.setLaneId(2000);

        MomsMessage momsMessage = new MomsMessage();
        momsMessage.setMomsTxId(1L);
        momsMessage.setPlazaId(info.getPlazaId());
        momsMessage.setLaneId(info.getLaneId());
        momsMessage.setTxDate(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        momsMessage.setMessageCode("message_code");
        momsMessage.setUpdateTs(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        momsMessage.setSentFlag(0);
        momsMessage.setSentTs(new Date());
        momsMessage.setEquipId(0);
        momsMessage.setAlarmId(2);
        momsMessage.setDescription("Invalid plaza lane_id in image file");

        Mockito.when(mockMomsMessageRepository.findByAlarmId(2)).thenReturn(null);
        Mockito.when(mockAppClient.getLanePlazaId()).thenReturn(new ResponseEntity(result, HttpStatus.OK));
        verify(mockMomsMessageRepository, Mockito.times(1)).findByAlarmId(2);
    }

//    @Test
//    @MockitoSettings(strictness = Strictness.WARN)
    void testInsertMomsMessageException() throws OBOException{
        String result = "{\"plazaId\": 920, \"laneId\" : 200}";
        MomsMessage momsMessage = new MomsMessage();
        momsMessage.setMomsTxId(0);
        momsMessage.setPlazaId(920);
        momsMessage.setLaneId(200);
        momsMessage.setTxDate(new Date());
        momsMessage.setMessageCode("IMAGE UNZIP");
        momsMessage.setUpdateTs(new Date());
        momsMessage.setSentFlag(0);
        momsMessage.setSentTs(new Date());
        momsMessage.setEquipId(9108);
        momsMessage.setAlarmId(4);
        momsMessage.setDescription("No VDF/ODF files or no content in VDF/ODF files");
        Mockito.when(mockAppClient.getLanePlazaId()).thenReturn(new ResponseEntity<>(result, HttpStatus.OK));
}


    void testInsertMomsMessageDataAccessException() throws OBOException{
        String result = "{\"plazaId\": 920, \"laneId\" : 200}";
        MomsMessage momsMessage = new MomsMessage();
        momsMessage.setMomsTxId(0);
        momsMessage.setPlazaId(920);
        momsMessage.setLaneId(200);
        momsMessage.setTxDate(new Date());
        momsMessage.setMessageCode("IMAGE UNZIP");
        momsMessage.setUpdateTs(new Date());
        momsMessage.setSentFlag(0);
        momsMessage.setSentTs(new Date());
        momsMessage.setEquipId(9108);
        momsMessage.setAlarmId(4);
        momsMessage.setDescription("No VDF/ODF files or no content in VDF/ODF files");

    }

}
